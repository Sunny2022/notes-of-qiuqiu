#include "Student.h"
#include <cstring>
using namespace std;

Student::Student(char *name,int d1,int d2,int d3){
    if(strlen(name)>9){
        cout<<"Error: The name is too long!"<<endl;
        return;
    }
    strcpy(m_name,name);
    m_deg1=d1;
    m_deg2=d2;
    m_deg3=d3;
}

void Student::setInfo(char *name,int d1,int d2,int d3){
    if(strlen(name)>9){
        cout<<"Error: The name is too long!"<<endl;
        return;
    }
    strcpy(m_name,name);
    m_deg1=d1;
    m_deg2=d2;
    m_deg3=d3;
    cout<<"name:"<<m_name<<"\nscore of deg1:"<<m_deg1
        <<"\nscore of deg2:"<<m_deg2
        <<"\nscore of deg3:"<<m_deg3
        <<endl
        <<endl;
}

Student operator+(Student &stu1,Student &stu2){
    Student stu;
    stu.m_deg1=stu1.m_deg1+stu2.m_deg1;
    stu.m_deg2=stu1.m_deg2+stu2.m_deg2;
    stu.m_deg3=stu1.m_deg3+stu2.m_deg3;
    return stu;
}

void avg(Student *stu,int n){
    Student s;
    float N=n;
    for(int i=0;i<n;i++){
        s=s+stu[i];
    }
    cout<<"average of deg1="<<s.m_deg1/N
        <<"\naverage of deg2="<<s.m_deg2/N
        <<"\naverage of deg3="<<s.m_deg3/N
        <<endl;
}
