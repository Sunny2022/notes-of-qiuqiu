#ifndef STUDENT_H_INCLUDED
#define STUDENT_H_INCLUDED

#include <iostream>

class Student{
private:
    char m_name[10];
    int m_deg1,m_deg2,m_deg3;
public:
    Student(){m_deg1=m_deg2=m_deg3=0;*(m_name)='\0';}
    Student(char*,int,int,int);
    void setInfo(char*,int,int,int);
    friend Student operator+(Student&,Student&);
    friend void avg(Student*,int);
};

#endif // STUDENT_H_INCLUDED
