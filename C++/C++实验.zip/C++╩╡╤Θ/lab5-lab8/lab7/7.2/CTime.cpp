#include "CTime.h"

using namespace std;
CTime::CTime(){
    m_hour=0;
    m_minute=0;
    m_second=0;
}

CTime::CTime(int hour,int minute,int second){
    m_hour=hour;
    m_minute=minute;
    m_second=second;
}

CTime::CTime(CTime &ctime){
    m_hour=ctime.m_hour;
    m_minute=ctime.m_minute;
    m_second=ctime.m_second;
}

void CTime::display(){
    cout<<m_hour<<":"<<m_minute<<":"<<m_second<<endl;
}

void CTime::setHour(int hour){
    m_hour=hour;
}
void CTime::setMinute(int minute){
    m_minute=minute;
}
void CTime::setSecond(int second){
    m_second=second;
}
//����
CTime& CTime::operator++(int){
    CTime ctime=*this;
    m_second++;
    if(m_second==60){
        m_second=0;
        m_minute++;
        if(m_minute==60){
            m_minute=0;
            m_hour++;
            if(m_hour==24)m_hour=0;
        }
    }
    return ctime;
}
//ǰ��
CTime& CTime::operator++(){
    m_second++;
    if(m_second==60){
        m_second=0;
        m_minute++;
        if(m_minute==60){
            m_minute=0;
            m_hour++;
            if(m_hour==24)m_hour=0;
        }
    }
    return *this;
}
