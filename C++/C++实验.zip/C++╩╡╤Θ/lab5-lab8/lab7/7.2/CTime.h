#ifndef CTIME_H_INCLUDED
#define CTIME_H_INCLUDED
#include <iostream>

class CTime{
private:
    int m_hour,m_minute,m_second;
public:
    CTime();
    CTime(int hour,int minute,int second);
    CTime(CTime &);
    void display();
    void setHour(int hour);
    void setMinute(int minute);
    void setSecond(int second);
    CTime& operator++(int);
    CTime& operator++();
};


#endif // CTIME_H_INCLUDED
