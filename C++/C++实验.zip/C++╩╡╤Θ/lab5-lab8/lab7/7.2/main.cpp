//------------------------------------------------------
// main.cpp
// Created by ����Դ on 2020/5/30.
//
//���һ��CTime��
//
//sunyy18@lzu.edu.cn
//------------------------------------------------------

#include "CTime.h"

using namespace std;
int main()
{
    int i;
    CTime ctime(13,45,39);
    for(i=0;i<30;i++)
    {
        ctime++;
        ctime.display();
    }
    ctime.setHour(23);
    ctime.setMinute(58);
    ctime.setSecond(5);
    cout<<endl;
    for(i=0;i<30;i++)
    {
        ctime++;
        ctime.display();
    }

    return 0;
}
