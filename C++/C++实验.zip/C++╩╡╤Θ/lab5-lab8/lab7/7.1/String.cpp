#include "String.h"
#include <iostream>
using namespace std;

String::String(char *str){
    if(str==nullptr)return;
    m_size=strlen(str);
    m_str=new char[m_size+1];
    strcpy(m_str,str);
}

String::String(const String &str){
    m_size=str.m_size;
    if(str.m_str!=nullptr){
        m_str=new char[m_size+1];
        strcpy(m_str,str.m_str);
    }
}

/*void String::setStr(char * str1){
    //cout<<str1<<endl;
    m_size=strlen(str1);
    //cout<<m_size<<endl<<strlen(str1)<<endl;
    if(str1!=nullptr){
        m_str=new char[m_size+1];
        //cout<<strlen(m_str)<<endl;
        strcpy(m_str,str1);
        //cout<<m_size<<endl<<strlen(str1)<<endl;
        //cout<<m_str<<endl;
        //*(m_str+m_size+1)='\0';
    }
}*/

bool String::operator==(const String &str){
    if(m_size!=str.m_size)return false;
    if(strcmp(m_str,str.m_str)!=0)return false;
    return true;

}

bool String::operator<(const String &str){
    if(strcmp(m_str,str.m_str)<0)return true;
    return false;
}

bool String::operator>(const String &str){
    if(strcmp(m_str,str.m_str)>0)return true;
    return false;
}

String::~String(){
    if(m_str!=nullptr){
        delete m_str;
        m_size=0;
    }
}

ostream & operator<<(ostream & os,const String &str){
    os<<str.m_str;
	return os;
}

istream & operator>>(istream & is,String &str){
    int i;
    char *str1=new char[100];
    is>>str1;
    str.m_size=strlen(str1);
    if(str1!=nullptr){
        str.m_str=new char[str.m_size+1];
        for(i=0;i<str.m_size+1;i++){
            *(str.m_str+i)=*(str1+i);
        }
    }
	return is;
}
