#ifndef STRING_H_INCLUDED
#define STRING_H_INCLUDED

#include <iostream>
#include <cstring>

class String{
private:
    char *m_str;
    int m_size;
public:
    String(char *str='\0');
    String(const String &);

    bool operator ==(const String &);
    bool operator >(const String &);
    bool operator <(const String &);
    ~String();
    friend std::ostream & operator<< (std::ostream &,const String &);
    friend std::istream & operator>> (std::istream &,String &);
};

#endif // STRING_H_INCLUDED
