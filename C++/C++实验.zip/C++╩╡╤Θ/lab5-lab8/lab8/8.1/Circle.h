#ifndef CIRCLE_H_INCLUDED
#define CIRCLE_H_INCLUDED
#include "Shape.h"
#include <iostream>

class Circle:public Shape{
private:
    float m_x,m_y,m_r;
public:
    Circle();
    Circle(Circle &);
    Circle(float,float,float);
    virtual float getArea();
    virtual void show();
    void setX(float);
    void setY(float);
    void setR(float);
    void Set(float,float,float);
};

#endif // CIRCLE_H_INCLUDED
