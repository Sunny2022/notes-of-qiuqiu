#ifndef SHAPE_H_INCLUDED
#define SHAPE_H_INCLUDED
#include <iostream>
class Shape{
public:
    Shape(){};
    virtual float getArea()=0;
    virtual void show()=0;
};

#endif // SHAPE_H_INCLUDED
