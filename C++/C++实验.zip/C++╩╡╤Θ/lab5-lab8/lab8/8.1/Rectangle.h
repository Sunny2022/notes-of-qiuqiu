#ifndef RECTANGLE_H_INCLUDED
#define RECTANGLE_H_INCLUDED
#include <iostream>
#include "Shape.h"

class Rectangle:public Shape{
private:
    float m_l,m_w;
public:
    Rectangle();
    Rectangle(Rectangle &);
    Rectangle(float,float);
    float getArea();
    void show();
    void setL(float);//�޸ĳ�
    void setW(float);//�޸Ŀ�
    void Set(float,float);
};

#endif // RECTANGLE_H_INCLUDED
