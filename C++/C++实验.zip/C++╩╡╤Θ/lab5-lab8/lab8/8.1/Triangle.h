#ifndef TRIANGLE_H_INCLUDED
#define TRIANGLE_H_INCLUDED
#include "Shape.h"
#include <iostream>

class Triangle:public Shape{
private:
    float m_x1,m_y1;
    float m_x2,m_y2;
    float m_x3,m_y3;
public:
    Triangle();
    Triangle(Triangle &);
    Triangle(float,float,float,float,float,float);
    float getArea();
    void show();
    void Set(float,float,float,float,float,float);
    float GetSide(float,float,float,float);//��߳�
    bool IfTra(float,float,float,float,float,float);//�ж��ܲ��ܹ���������
};

#endif // TRIANGLE_H_INCLUDED
