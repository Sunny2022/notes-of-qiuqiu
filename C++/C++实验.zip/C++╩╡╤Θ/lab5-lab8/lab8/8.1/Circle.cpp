#include "Circle.h"

using namespace std;


Circle::Circle(){
    m_x=m_y=m_r=0;
}
Circle::Circle(Circle &c){
    m_x=c.m_x;
    m_y=c.m_y;
    m_r=c.m_r;
}
Circle::Circle(float x,float y,float r){
    if(r>0){
        m_x=x;
        m_y=y;
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}

float Circle::getArea(){
    return 3.14*m_r*m_r;
}

void Circle::show(){
    cout<<"\nԲ�ģ�("<<m_x<<","<<m_y<<")\n�뾶��"<<m_r<<"\n�����"<<getArea()<<endl;
}

void Circle::setX(float x){
    m_x=x;
}
void Circle::setY(float y){
    m_y=y;
}
void Circle::setR(float r){
    if(r>0){
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}
void Circle::Set(float x,float y,float r){
    if(r>0){
        m_x=x;
        m_y=y;
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}
