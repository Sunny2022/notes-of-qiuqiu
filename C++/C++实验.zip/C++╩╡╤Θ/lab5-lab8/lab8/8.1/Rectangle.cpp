#include "Rectangle.h"

using namespace std;

Rectangle::Rectangle(){
    m_l=m_w=0;
}
Rectangle::Rectangle(Rectangle &r){
    m_l=r.m_l;
    m_w=r.m_w;
}
Rectangle::Rectangle(float l,float w){
    m_l=l;
    m_w=w;
}
float Rectangle::getArea(){
    return m_l*m_w;
}
void Rectangle::show(){
    cout<<"\n�����γ���"<<m_l<<"\n�����ο���"<<m_w<<"\n�����"<<getArea()<<endl;
}
void Rectangle::setL(float l){        //�޸ĳ�
    m_l=l;
}
void Rectangle::setW(float w){          //�޸Ŀ�
    m_w=w;
}
void Rectangle::Set(float l,float w){
    m_l=l;
    m_w=w;
}
