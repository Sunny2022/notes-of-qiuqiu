#ifndef EMPLOYEE_H_INCLUDED
#define EMPLOYEE_H_INCLUDED

#include <iostream>
#include <string>
#include "Date.h"


class Employee
{
private:
    int m_ID;
    std::string m_name;
    char m_sex;
    Date m_birth_date;
    /*post:
    �ܾ���---1
    ������Ա---2
    ���۾���---3
    ����Ա---4*/
    int m_post;
    double m_salary;
public:
    Employee();
    Employee(const int,const std::string &,const char,int,int,int,int);
    virtual ~Employee() {}
    virtual void display() const =0;            //�麯��display

    int getID() const;
    void setID(int);
    const std::string &getName() const;
    void setName(const std::string &);
    char getSex() const;
    void setSex(char);
    int getPost() const;
    void setPost(int);
    double getSalary() const;
    void setSalary(double);
    virtual void pay()=0;                       //�麯��pay
    const Date &getBirthDate() const;
    void setBirthDate(const Date &);
    std::string whatPost(int)const;
    virtual void promote()=0;
};

#endif // EMPLOYEE_H_INCLUDED
