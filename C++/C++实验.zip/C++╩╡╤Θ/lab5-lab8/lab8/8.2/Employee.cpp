#include "Employee.h"
using namespace std;


Employee::Employee():m_birth_date(1900,1,1)
{
    setID(1001);
    setName("wangyu");
    setSex('M');
}

Employee::Employee(const int ID, const string &name, const char sex, int y, int m, int d,int post):m_birth_date(y,m,d)
{
    setID(ID);
    setName(name);
    setSex(sex);
    setPost(post);
}
//ID
int Employee::getID() const{return m_ID;}
void Employee::setID(int ID){m_ID = ID;}
//Name
const string &Employee::getName() const{return m_name;}
void Employee::setName(const string &name){m_name = name;}
//Sex
char Employee::getSex() const{return m_sex;}
void Employee::setSex(char sex){m_sex=sex;}
//Post
int Employee::getPost() const{return m_post;}
void Employee::setPost(int post){m_post = post;}
//Salary
double Employee::getSalary() const{return m_salary;}
void Employee::setSalary(double salary){m_salary=salary;}
//BirthDate
const Date &Employee::getBirthDate() const{return m_birth_date;}
void Employee::setBirthDate(const Date &birth_date){m_birth_date = birth_date;}

string Employee::whatPost(int p)const{
    /*post:
    �ܾ���---1
    ������Ա---2
    ���۾���---3
    ����Ա---4*/
    switch(p){
    case 1:return "�ܾ���";
    case 2:return "������Ա";
    case 3:return "���۾���";
    case 4:return "����Ա";
    default:return "error!";
    }
}
