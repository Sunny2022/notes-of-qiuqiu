#ifndef DATE_H_INCLUDED
#define DATE_H_INCLUDED

class Date{
private:
    int m_year, m_month, m_day;
public:
    Date(int year=1900, int month=1, int day=1) ;
    Date(Date &);
    void setYear(int) ;
    void setMonth(int);
    void setDay(int);
    int getYear()const;
    int getMonth()const;
    int getDay()const;

};

#endif // DATE_H_INCLUDED
