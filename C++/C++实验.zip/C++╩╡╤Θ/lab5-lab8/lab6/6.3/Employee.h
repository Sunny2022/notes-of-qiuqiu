#ifndef EMPLOYEE_H_INCLUDED
#define EMPLOYEE_H_INCLUDED

#include <iostream>
#include <string>
#include "Date.h"


class Employee
{
private:
    int m_ID;
    std::string m_name;
    char m_sex;
    Date m_birth_date;
    /*post:
    �ܾ���---1
    ������Ա---2
    ���۾���---3
    ����Ա---4*/
    int m_post;
    double m_salary;
public:
    Employee();
    Employee(const int ID,const std::string &name,const char &sex,int y,int m,int d,int post);
    virtual ~Employee() {}
    virtual void display() const =0;

    int getID() const;
    void setID(int m_code);
    const std::string &getName() const;
    void setName(const std::string &m_name);
    char getSex() const;
    void setSex(char m_sex);
    int getPost() const;
    void setPost(int m_post);
    double getSalary() const;
    void setSalary(double);
    virtual void pay()=0;
    const Date &getBirthDate() const;
    void setBirthDate(const Date &m_birth_date);
    std::string whatPost(int)const;
};


#endif // EMPLOYEE_H_INCLUDED
