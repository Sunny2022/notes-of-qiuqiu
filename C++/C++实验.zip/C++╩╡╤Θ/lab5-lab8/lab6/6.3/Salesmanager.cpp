#include "Salesmanager.h"
using namespace std;

Salesmanager::Salesmanager() : Manager(), Salesman()
{
    setPost(3);
    pay();
}

Salesmanager::Salesmanager(const int ID, const string &name, const char &sex, int y, int m, int d,
                           double sales, const string &department,int post)
        : Employee(ID, name, sex, y, m, d, post), Manager(), Salesman(sales, department)
{
    setSales(sales);
    setPost(3);
    pay();
}

void Salesmanager::pay(){
    setSalary(5000+getSales()*0.005);
}

void Salesmanager::display() const
{
    string sex;
    if(getSex()=='M')sex="��";
    else sex="Ů";
    cout << "\nSalesmanager��Ϣ��"
         << "\n��ţ�" <<getID()
         << "\n������" <<getName()
         << "\n�Ա�" <<sex
         << "\n�������ڣ�" <<getBirthDate().getYear() << "-"
         <<getBirthDate().getMonth() << "-"
         <<getBirthDate().getDay()
         << "\nְλ��" <<whatPost(Manager::getPost())
         << "\n���ʣ�" <<getSalary()
         << "\n��Ͻ�������۶" <<getSales()
         <<"\n��Ͻ������"<<getDepartment()
         << endl;
}

