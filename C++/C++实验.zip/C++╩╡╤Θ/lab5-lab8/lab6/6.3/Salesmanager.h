#ifndef SALEMANAGER_H_INCLUDED
#define SALEMANAGER_H_INCLUDED

#include "Manager.h"
#include "Salesman.h"

#define score 1000

class Salesmanager : public Manager, public Salesman
{
public:
    Salesmanager();
    Salesmanager(const int,const std::string &,const char &,int y,int m,int d,
                 double,const std::string &,int post=3);
    ~Salesmanager() {}
    virtual void pay();
    void display() const;
};


#endif // SALEMANAGER_H_INCLUDED
