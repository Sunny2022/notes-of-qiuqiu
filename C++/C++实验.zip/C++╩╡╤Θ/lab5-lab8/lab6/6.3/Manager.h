#ifndef MANAGER_H_INCLUDED
#define MANAGER_H_INCLUDED

#include "Employee.h"


class Manager : virtual public Employee
{
public:
    Manager();
    Manager(int,const std::string &,const char &,int,int,int,int post=1);
    ~Manager() {}

    virtual void pay();
    void display() const;
};

#endif // MANAGER_H_INCLUDED
