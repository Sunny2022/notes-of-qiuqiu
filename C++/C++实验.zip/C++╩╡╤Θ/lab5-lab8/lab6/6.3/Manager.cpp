#include "Manager.h"
using namespace std;

Manager::Manager():Employee()
{
    setPost(1);
    pay();
}

Manager::Manager(int ID,const string &name,const char &sex,int y,int m,int d,int post):
        Employee(ID,name,sex,y,m,d,post)
{
    setPost(post);
    pay();
}

void Manager::pay(){
    setSalary(8000);
}

void Manager::display()const
{
    string sex;
    if(getSex()=='M')sex="��";
    else sex="Ů";
    cout <<"\nManager��Ϣ��"
         <<"\n��ţ�"<<getID()
         <<"\n������"<<getName()
         <<"\n�Ա�"<<sex
         <<"\n�������ڣ�"<<getBirthDate().getYear()<<"-"
         <<getBirthDate().getMonth()<<"-"
         <<getBirthDate().getDay()
         <<"\nְλ��"<<whatPost(getPost())
         <<"\n���ʣ�"<<getSalary()
         <<endl;
}
