#include "Date.h"
Date::Date(int year,int month,int day) {
    m_year=year;
    m_month=month;
    m_day=day;
}

Date::Date(Date &birth_date) {
    m_year=birth_date.getYear();
    m_month=birth_date.getMonth();
    m_day=birth_date.getDay();
}


void Date::setYear(int year){m_year=year;}
void Date::setMonth(int month){m_month=month;}
void Date::setDay(int day){m_day=day;}


int Date::getYear()const{return m_year;}
int Date::getMonth()const{return m_month;}
int Date::getDay()const{return m_day;}
