#include "Cadre.h"
#include <iostream>
using namespace std;

Cadre::Cadre(){
    m_name="null";
    m_age=0;
    m_sex="male";
    m_address="000-000";
    m_phone="0000000";
    m_post="unknown";
}
Cadre::Cadre(string name,int age,string sex,string address,string phone,string post){
    m_name=name;    m_age=age;
    m_sex=sex;      m_address=address;
    m_phone=phone;  m_post=post;
}
void Cadre::display(){
    cout<<"\n����:"<<m_name<<"\n����:"<<m_age<<"\n�Ա�:"
        <<m_sex<<"\n��ַ:"<<m_address<<"\n�绰:"<<m_phone
        <<endl;
}
void Cadre::setCadre(string name,int age,string sex,string address,string phone,string post){
    m_name=name;    m_age=age;
    m_sex=sex;      m_address=address;
    m_phone=phone;  m_post=post;
}
