#ifndef TEACHER_CADRE_H_INCLUDED
#define TEACHER_CADRE_H_INCLUDED
#include "Teacher.h"
#include "Cadre.h"
#include <string>

class Teacher_Cadre:public Teacher,public Cadre{
    float m_wages;
public:
    Teacher_Cadre();
    Teacher_Cadre(std::string,int,std::string,std::string,std::string,std::string,std::string,float);
    void show(){Teacher::display();}
    void display();
    void setTeacher_Cadre(std::string,int,std::string,std::string,std::string,std::string,std::string,float);
};

#endif // TEACHER_CADRE_H_INCLUDED
