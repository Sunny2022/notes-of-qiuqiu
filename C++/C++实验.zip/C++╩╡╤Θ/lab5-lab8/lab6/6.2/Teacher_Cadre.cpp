#include "Teacher_Cadre.h"
#include <iostream>
using namespace std;

Teacher_Cadre::Teacher_Cadre(){
    setTeacher("null",0,"male","000-000","0000000","unknown");
    setCadre("null",0,"male","000-000","0000000","unknown");
    m_wages=0;
}
Teacher_Cadre::Teacher_Cadre(string name,int age,string sex,string address,string phone,string title,string post,float wages){
    setTeacher(name,age,sex,address,phone,title);
    setCadre(name,age,sex,address,phone,post);
    m_wages=wages;
}
void Teacher_Cadre::display(){
    cout<<"\n����:"<<Teacher::getName()<<"\n����:"<<Teacher::getAge()
        <<"\n�Ա�:"<<Teacher::getSex()<<"\n��ַ:"<<Teacher::getAddress()
        <<"\n�绰:"<<Teacher::getPhone()<<"\nְ��:"<<Teacher::getTitle()
        <<"\nְ��:"<<Cadre::getPost()<<"\n����:"<<m_wages
        <<endl<<endl;
}
void Teacher_Cadre::setTeacher_Cadre(string name,int age,string sex,string address,string phone,string title,string post,float wages){
    setTeacher(name,age,sex,address,phone,title);
    setCadre(name,age,sex,address,phone,post);
    m_wages=wages;
}
