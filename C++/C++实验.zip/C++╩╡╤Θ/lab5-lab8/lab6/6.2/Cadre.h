#ifndef CADRE_H_INCLUDED
#define CADRE_H_INCLUDED
#include <string>

class Cadre{
    std::string m_name;
    int m_age;
    std::string m_sex,m_address,m_phone,m_post;
public:
    Cadre();
    Cadre(std::string,int,std::string,std::string,std::string,std::string);
    void display();
    void setCadre(std::string,int,std::string,std::string,std::string,std::string);

    std::string getPost(){return m_post;}
};

#endif // CADRE_H_INCLUDED
