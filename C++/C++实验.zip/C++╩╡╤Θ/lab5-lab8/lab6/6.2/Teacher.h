#ifndef TEACHER_H_INCLUDED
#define TEACHER_H_INCLUDED
#include <string>

class Teacher{
    std::string m_name;
    int m_age;
    std::string m_sex,m_address,m_phone,m_title;
public:
    Teacher();
    Teacher(std::string,int,std::string,std::string,std::string,std::string);
    void display();
    void setTeacher(std::string,int,std::string,std::string,std::string,std::string);

    std::string getName(){return m_name;}
    int getAge(){return m_age;}
    std::string getSex(){return m_sex;}
    std::string getAddress(){return m_address;}
    std::string getPhone(){return m_phone;}
    std::string getTitle(){return m_title;}
};

#endif // TEACHER_H_INCLUDED
