#include "Teacher.h"
#include <iostream>
using namespace std;

Teacher::Teacher(){
    m_name="null";
    m_age=0;
    m_sex="male";
    m_address="000-000";
    m_phone="0000000";
    m_title="unknown";
}
Teacher::Teacher(string name,int age,string sex,string address,string phone,string title){
    m_name=name;    m_age=age;
    m_sex=sex;      m_address=address;
    m_phone=phone;  m_title=title;
}
void Teacher::display(){
    cout<<"\n����:"<<m_name<<"\n����:"<<m_age<<"\n�Ա�:"
        <<m_sex<<"\n��ַ:"<<m_address<<"\n�绰:"<<m_phone
        <<endl;
}
void Teacher::setTeacher(string name,int age,string sex,string address,string phone,string title){
    m_name=name;    m_age=age;
    m_sex=sex;      m_address=address;
    m_phone=phone;  m_title=title;
}
