#include "Shape.h"
#include <cmath>
using namespace std;

//Circle��
Circle::Circle(){
    m_x=m_y=m_r=0;
}
Circle::Circle(Circle &c){
    m_x=c.m_x;
    m_y=c.m_y;
    m_r=c.m_r;
}
Circle::Circle(float x,float y,float r){
    if(r>0){
        m_x=x;
        m_y=y;
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}

float Circle::getArea(){
    return 3.14*m_r*m_r;
}

void Circle::show(){
    cout<<"\nԲ�ģ�("<<m_x<<","<<m_y<<")\n�뾶��"<<m_r<<"\n�����"<<getArea()<<endl;
}

void Circle::setX(float x){
    m_x=x;
}
void Circle::setY(float y){
    m_y=y;
}
void Circle::setR(float r){
    if(r>0){
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}
void Circle::Set(float x,float y,float r){
    if(r>0){
        m_x=x;
        m_y=y;
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}

//Rectangle��
Rectangle::Rectangle(){
    m_l=m_w=0;
}
Rectangle::Rectangle(Rectangle &r){
    m_l=r.m_l;
    m_w=r.m_w;
}
Rectangle::Rectangle(float l,float w){
    m_l=l;
    m_w=w;
}
float Rectangle::getArea(){
    return m_l*m_w;
}
void Rectangle::show(){
    cout<<"\n�����γ���"<<m_l<<"\n�����ο���"<<m_w<<"\n�����"<<getArea()<<endl;
}
void Rectangle::setL(float l){        //�޸ĳ�
    m_l=l;
}
void Rectangle::setW(float w){          //�޸Ŀ�
    m_w=w;
}
void Rectangle::Set(float l,float w){
    m_l=l;
    m_w=w;
}

//Triangle��
Triangle::Triangle(){
    m_x1=m_y1=0;
    m_x2=m_y2=0;
    m_x3=m_y3=0;
}
Triangle::Triangle(float x1,float y1,float x2,float y2,float x3,float y3){
    if(IfTra(x1,y1,x2,y2,x3,y3)){
        m_x1=x1;m_y1=y1;
        m_x2=x2;m_y2=y2;
        m_x3=x3;m_y3=y3;
    }
    else{
        cout<<"���ܹ���һ�������Σ�"<<endl;
        return;
    }
}
Triangle::Triangle(Triangle &t){
    m_x1=t.m_x1;m_y1=t.m_y1;
    m_x2=t.m_x2;m_y2=t.m_y2;
    m_x3=t.m_x3;m_y3=t.m_y3;
}
float Triangle::getArea(){
    float a,b,c,d;
    a=GetSide(m_x1,m_y1,m_x2,m_y2);
    b=GetSide(m_x2,m_y2,m_x3,m_y3);
    c=GetSide(m_x1,m_y1,m_x3,m_y3);
    d=(a+b+c)/2.0;
    return sqrt(d*(d-a)*(d-b)*(d-c));
}
void Triangle::show(){
    cout<<"\n�����ε����������ǣ�("
    <<m_x1<<","<<m_y1<<")��("
    <<m_x2<<","<<m_y2<<")��("
    <<m_x3<<","<<m_y3<<")"
    <<"\n����ǣ�"<<getArea()<<endl;
}
void Triangle::Set(float x1,float y1,float x2,float y2,float x3,float y3){
    if(IfTra(x1,y1,x2,y2,x3,y3)){
        m_x1=x1;m_y1=y1;
        m_x2=x2;m_y2=y2;
        m_x3=x3;m_y3=y3;
    }
    else{
        cout<<"���ܹ���һ�������Σ�"<<endl;
        return;
    }
}
float Triangle::GetSide(float x1,float y1,float x2,float y2){
    return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
bool Triangle::IfTra(float x1,float y1,float x2,float y2,float x3,float y3){
    float a,b,c;
    a=GetSide(x1,y1,x2,y2);
    b=GetSide(x2,y2,x3,y3);
    c=GetSide(x1,y1,x3,y3);
    return a + b > c && a + c > b && b + c > a;
}
