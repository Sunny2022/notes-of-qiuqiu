#ifndef SHAPE_H_INCLUDED
#define SHAPE_H_INCLUDED

#include <iostream>

class Shape{
public:
    Shape(){};
    virtual float getArea()=0;
    virtual void show()=0;
};

class Circle:public Shape{
private:
    float m_x,m_y,m_r;
public:
    Circle();
    Circle(Circle &);
    Circle(float,float,float);
    virtual float getArea();
    virtual void show();
    void setX(float);
    void setY(float);
    void setR(float);
    void Set(float,float,float);
};

class Rectangle:public Shape{
private:
    float m_l,m_w;
public:
    Rectangle();
    Rectangle(Rectangle &);
    Rectangle(float,float);
    float getArea();
    void show();
    void setL(float);//修改长
    void setW(float);//修改宽
    void Set(float,float);
};

class Triangle:public Shape{
private:
    float m_x1,m_y1;
    float m_x2,m_y2;
    float m_x3,m_y3;
public:
    Triangle();
    Triangle(Triangle &);
    Triangle(float,float,float,float,float,float);
    float getArea();
    void show();
    void Set(float,float,float,float,float,float);
    float GetSide(float,float,float,float);//求边长
    bool IfTra(float,float,float,float,float,float);//判断能不能构成三角形
};

#endif // SHAPE_H_INCLUDED
