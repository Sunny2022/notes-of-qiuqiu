#include "Date.h"
Date::Date(int year,int month,int day) {
    m_year=year;
    m_month=month;
    m_day=day;
}

Date::Date(Date &birth_date) {
    m_year=birth_date.getYear();
    m_month=birth_date.getMonth();
    m_day=birth_date.getDay();
}

//SET����
void Date::setYear(int year){m_year=year;}
void Date::setMonth(int month){m_month=month;}
void Date::setDay(int day){m_day=day;}

//GET����
int Date::getYear(){return m_year;}
int Date::getMonth(){return m_month;}
int Date::getDay(){return m_day;}
