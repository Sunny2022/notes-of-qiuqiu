#ifndef DATE_H
#define DATE_H
class Date {
	private:
		int m_year, m_month, m_day;
	public:
		Date(int year=1900, int month=1, int day=1) ;
		Date(Date &);
		void setYear(int y) ;
		void setMonth(int m);
		void setDay(int d);
		int getYear() ;
		int getMonth();
		int getDay();
};
#endif // DATE_H
