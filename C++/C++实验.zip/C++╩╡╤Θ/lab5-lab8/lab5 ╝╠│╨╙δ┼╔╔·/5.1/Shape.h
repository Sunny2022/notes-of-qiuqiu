#ifndef SHAPE_H_INCLUDED
#define SHAPE_H_INCLUDED


class Circle{
protected:
    float m_x;
    float m_y;
    float m_r;
public:
    Circle();
    Circle(float,float,float);
    Circle(Circle &);
    float GetArea();
    void Show();
    void Set(float,float,float);
};

class Rectangle{
protected:
    float m_l;
    float m_w;
public:
    Rectangle();
    Rectangle(float,float);
    Rectangle(Rectangle &);
    float GetArea();
    void Show();
    void Set(float,float);
};


class Triangle{
protected:
    float m_x1,m_y1;
    float m_x2,m_y2;
    float m_x3,m_y3;
public:
    Triangle();
    Triangle(float,float,float,float,float,float);
    Triangle(Triangle &);
    float GetArea();
    void Show();
    void Set(float,float,float,float,float,float);
    float GetSide(float,float,float,float);//��߳�
    bool IfTra(float,float,float,float,float,float);//�ж��ܲ��ܹ���������
};

#endif // SHAPE_H_INCLUDED
