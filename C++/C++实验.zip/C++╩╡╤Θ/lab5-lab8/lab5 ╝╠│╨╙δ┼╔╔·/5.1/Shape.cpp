#include "Shape.h"
#include <iostream>
#include <cmath>
#define PI 3.14

using namespace std;

//Բ�ĺ�����Ա����
Circle::Circle(){
    m_x=0;
    m_y=0;
    m_r=0;
}
Circle::Circle(float x,float y,float r){
    if(r>0){
        m_x=x;
        m_y=y;
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }

}
Circle::Circle(Circle &c){
    m_x=c.m_x;
    m_y=c.m_y;
    m_r=c.m_r;
}
float Circle::GetArea(){
    return PI*m_r*m_r;
}
void Circle::Show(){
    cout<<"\nԲ���ǣ�("<<m_x<<","<<m_y<<")\nԲ�İ뾶�ǣ�"<<m_r<<"\n����ǣ�"<<GetArea()<<endl;
}
void Circle::Set(float x,float y,float r){
    if(r>0){
        m_x=x;
        m_y=y;
        m_r=r;
    }
    else{
        cout<<"\nerror:�뾭Ҫ�����㣡"<<endl;
        return;
    }
}

//���εĺ�����Ա����
Rectangle::Rectangle(){
    m_l=0;
    m_w=0;
}
Rectangle::Rectangle(float l,float w){
    m_l=l;
    m_w=w;
}
Rectangle::Rectangle(Rectangle &r){
    m_l=r.m_l;
    m_w=r.m_w;
}
float Rectangle::GetArea(){
    return m_l*m_w;
}
void Rectangle::Show(){
    cout<<"\n���εĳ��ǣ�"<<m_l<<"\n���εĿ��ǣ�"<<m_w<<"\n����ǣ�"<<GetArea()<<endl;
}
void Rectangle::Set(float l,float w){
    m_l=l;
    m_w=w;
}

//�����εĺ�����Ա����
Triangle::Triangle(){
    m_x1=0;m_y1=0;
    m_x2=0;m_y2=0;
    m_x3=0;m_y3=0;
}
Triangle::Triangle(float x1,float y1,float x2,float y2,float x3,float y3){
    if(IfTra(x1,y1,x2,y2,x3,y3)){
        m_x1=x1;m_y1=y1;
        m_x2=x2;m_y2=y2;
        m_x3=x3;m_y3=y3;
    }
    else{
        cout<<"���ܹ���һ�������Σ�"<<endl;
        return;
    }
}
Triangle::Triangle(Triangle &t){
    m_x1=t.m_x1;m_y1=t.m_y1;
    m_x2=t.m_x2;m_y2=t.m_y2;
    m_x3=t.m_x3;m_y3=t.m_y3;
}
float Triangle::GetArea(){
    float a,b,c,d;
    a=GetSide(m_x1,m_y1,m_x2,m_y2);
    b=GetSide(m_x2,m_y2,m_x3,m_y3);
    c=GetSide(m_x1,m_y1,m_x3,m_y3);
    d=(a+b+c)/2.0;
    return sqrt(d*(d-a)*(d-b)*(d-c));
}
void Triangle::Show(){
    cout<<"\n�����ε����������ǣ�("<<m_x1<<","<<m_y1<<")��("<<m_x2<<","<<m_y2<<")��("<<m_x3<<","<<m_y3<<")"<<"\n����ǣ�"<<GetArea()<<endl;
}
void Triangle::Set(float x1,float y1,float x2,float y2,float x3,float y3){
    if(IfTra(x1,y1,x2,y2,x3,y3)){
        m_x1=x1;m_y1=y1;
        m_x2=x2;m_y2=y2;
        m_x3=x3;m_y3=y3;
    }
    else{
        cout<<"���ܹ���һ�������Σ�"<<endl;
        return;
    }
}
float Triangle::GetSide(float x1,float y1,float x2,float y2){
    return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}
bool Triangle::IfTra(float x1,float y1,float x2,float y2,float x3,float y3){
    float a,b,c;
    a=GetSide(x1,y1,x2,y2);
    b=GetSide(x2,y2,x3,y3);
    c=GetSide(x1,y1,x3,y3);
    return a + b > c && a + c > b && b + c > a;
}
