#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

#include <iostream>
#include <fstream>
#define MaxSize 100

using namespace std;

bool ifMatch(char *filename);

class Stack{
private:
    char m_stack[MaxSize];
    int m_top=0;
public:
    void initStack();
    void push(char item);
    char pop();
    char peek();
    bool isEmpty();
    void clearStack();
};

#endif // STACK_H_INCLUDED
