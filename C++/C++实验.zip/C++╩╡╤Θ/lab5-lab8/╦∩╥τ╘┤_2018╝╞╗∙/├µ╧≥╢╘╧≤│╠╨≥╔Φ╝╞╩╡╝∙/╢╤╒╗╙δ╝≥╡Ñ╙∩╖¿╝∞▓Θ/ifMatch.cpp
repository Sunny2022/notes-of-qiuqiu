#include "Stack.h"

bool ifMatch(char *filename){
    Stack stack_;
    char ch;
    ifstream filein(filename, ios::in);
    if(!filein) {
        cout<<"Error: fail to open the file!"<<endl;
        abort();
    }

    stack_.initStack();//��ʼ��ջ
    while(true) {
        filein>>ch;
        if(filein.eof()) break;
        //cout<<ch;
        if(ch == '{' || ch == '[' || ch == '(')  //��������ջ
            stack_.push(ch);
        else if(ch == '}' || ch == ']' || ch == ')'){//�����ų�ջ
            if(stack_.isEmpty()) return 0;
            switch(ch){
                case '}' : {
                    if(stack_.peek() == '{')
                        stack_.pop();
                    else return 0;
                    break;
                }
                case ']' : {
                    if(stack_.peek() == '[')
                        stack_.pop();
                    else return 0;
                    break;
                }
                case ')' : {
                    if(stack_.peek() == '(')
                        stack_.pop();
                    else return 0;
                    break;
                }
            }
        }
    }
    if(stack_.isEmpty())return true;
    else return false;
}
