#ifndef STUDENT_H_INCLUDED
#define STUDENT_H_INCLUDED

#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;


class Student
{
public:
    Student();
    Student(const char*,int,int Chinese = 100, int math=100,int English = 100);

    virtual ~Student();

    friend ostream &operator<<(ostream&,const Student&);
    Student &operator=(Student);
    void append();
    void input();
    void setInfo(const char*,int,int,int,int);

    const char *getName() const;
    void setName(const char*);
    int getID() const;
    void setID(int);
    int getChinese() const;
    void setChinese(int);
    int getMath() const;
    void setMath(int);
    int getEnglish() const;
    void setEnglish(int);
    int getTotal()const;
    void setTotal();


private:
    char m_name[20];
    int m_ID;
    int m_chinese;
    int m_math;
    int m_english;
    int m_total;
};

const Student mark("nobody", 0, 0, 0, 0);


void initial();//��ʼ���ļ�
void showFile();//����ļ�����
void showOnCondition();//�����Ӧ������

void appendInfo();//׷��ѧ����Ϣ
void searchInfo();//Ѱ��ѧ������
void sortInfo();//����ѧ���ɼ�
void deleteInfo();//ɾ��ѧ����Ϣ
void changeInfo();//�޸�ѧ����Ϣ
#endif // STUDENT_H_INCLUDED
