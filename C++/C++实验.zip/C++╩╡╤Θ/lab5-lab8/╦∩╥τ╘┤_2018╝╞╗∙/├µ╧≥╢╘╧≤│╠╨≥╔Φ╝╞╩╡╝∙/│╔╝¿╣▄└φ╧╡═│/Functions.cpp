#include "Student.h"
string filename="studentInfo";
void initial()
{
    fstream fileout(filename, ios::out | ios::binary);

    fileout.seekp(0, ios::beg);
    fileout.write((char *) &mark, sizeof(Student));
    cout << "��ʼ����ɣ�" << endl;

    fileout.close();
    return;
}

void showFile()
{
    ifstream filein(filename, ios::in);
    if (!filein)
    {
        cout<<"Error: fail to open the file!" << endl;
        return;
    }
    Student s;
    s.setID(1);
    cout << "����\tѧ��\t����\t��ѧ\tӢ��\t�ܳɼ�" << endl;
    while(true)
    {
        filein.read((char *) &s, sizeof(Student));
        if(s.getID()==0)break;
        cout << s << "\n";
    }
    filein.close();
}


void showOnCondition()
{
    Student s;
    ifstream filein(filename, ios::in);
    if (!filein)
    {
        cerr << "Error: fail to open the file!" << endl;
        return;
    }
    filein.read((char *) &s, sizeof(Student));

    if (s.getID() == 0)
    {
        cout << "������Ϣ��" << endl;
        return;
    }

    int min,max;
    int choice;

    cout << "��������ʾ��ʽ��Ӧ����ţ�"
         << "\n1��������"
         << "\n2������ѧ"
         << "\n3����Ӣ��"
         << "\n4�����ܷ�"<<endl;
    cin>>choice;
    cout<<"��������ʾ��Χ����ͳɼ���";
    cin>>min;
    cout<<"��������ʾ��Χ����߳ɼ���";
    cin>>max;
    cout<<"��Ϣ���£�"
        <<"����\tѧ��\t����\t��ѧ\tӢ��\t�ܷ�"<<endl;
    filein.seekg(0,ios::beg);
    while(true)
    {
        filein.read((char *)&s,sizeof(Student));
        if(filein.eof())break;
        if (s.getID() == 0)return;
        switch (choice)
        {
            case 1:
                if (s.getChinese()>= min && s.getChinese()<= max)
                    cout<<s<<endl;
                break;
            case 2:
                if (s.getMath()>= min&&s.getMath()<= max)
                    cout<<s<<endl;
                break;
            case 3:
                if (s.getEnglish()>=min&&s.getEnglish()<= max)
                    cout<<s<<endl;
                break;
            default:cout<<"�Ƿ����룡��������"<<endl;
                return;
        }
    }
    filein.close();
}

void appendInfo()
{
    while(true)
    {
        Student s;
        char choice;
        s.input();

        Student s1;
        fstream fileinout(filename, ios::in | ios::out | ios::binary);
        if (!fileinout)
        {
            cout << "Error: fail to open the file." << endl;
            return;
        }
        fileinout.seekg(0, ios::beg);
        s1.setID(1);
        while(s1.getID()!=0)fileinout.read((char *) &s1, sizeof(Student));

        fileinout.seekp(-long(sizeof(Student)), ios::cur);
        fileinout.write((char *) &s, sizeof(Student));
        fileinout.write((char *) &mark, sizeof(Student));//��βд�ر�־ѧ��
        fileinout.close();
        cout<< "\n���ӳɹ����Ƿ��������?(y/n): ";
        cin>>choice;
        if(choice=='N'||choice== 'n')
        {
            cout<<"�õģ��������ء���"<<endl;
            return;
        }
    }
}

void searchInfo()
{
    Student s;
    s.setID(1);
    fstream filein(filename, ios::in | ios::binary);

    int choice;

    cout << "\n��������ҷ�ʽ��Ӧ����ţ�"
         << "\n1��ͨ������\n2��ͨ��ѧ��"<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1:
        {
            char name[10];
            cout<<"\n������Ҫ���ҵ�ѧ������:"<<endl;
            cin >> name;
            while(s.getID()!= 0)
            {
                filein.read((char *)&s,sizeof(Student));
                if(strcmp(s.getName(),name)==0)break;
            }
            if (strcmp(s.getName(),name)==0)cout << s;
            else cout << "\n���Ҳ�������ˣ�" << endl;
            break;
        }
        case 2:
        {
            int ID;
            cout<<"\n������Ҫ�����˵�ѧ�ţ�"<<endl;
            cin>>ID;
            while(s.getID()!= 0)
            {
                filein.read((char *)&s,sizeof(Student));
                if(s.getID()==ID)break;
            }
            if (s.getID() == ID)cout << s;
            else cout << "\n�Ҳ��������." << endl;
            break;
        }
        default:cout<<"�Ƿ����룬���飡"<<endl;
    }
    filein.close();
}

void sortInfo()
{
    Student *stu = nullptr;
    Student s;
    int number = 0;
    int i,j,temp;
    fstream filein(filename, ios::in | ios::binary);
    s.setID(1);
    while(s.getID()!= 0)
    {
        filein.read((char *) &s, sizeof(Student));
        number++;
    }
    if (number == 1)//û������ֱ�ӷ���
    {
        cout <<"ѧ���ɼ����ݿ�Ϊ�գ���������Ϣ���ٽ��д˲�������������"<< endl;
        return;
    }
    filein.seekg(0, ios::beg);
    stu = new Student[number];
    if (stu==nullptr)
    {
        cout <<"�ڴ����ʧ�ܣ�"<< endl;
        return;
    }
    for (i=0;i<number;i++)filein.read((char *)&stu[i], sizeof(Student));
    filein.close();

    //��ʼ����
    int choice1,choice2;
    cout<<"\n�����������׼��Ӧ����ţ�"
        <<"\n1��������"
        <<"\n2������ѧ"
        <<"\n3����Ӣ��"
        <<"\n4�����ܷ�"<<endl;
    cin>>choice1;
    cout<<"\n���������򷽷���Ӧ����ţ�"
        <<"\n 1��ð������\n 2��ѡ������"<<endl;
    cin>>choice2;

    if (choice1==1&&choice2==1)//����ð��
    {
        for(i=0;i<number-1;i++)
        {
            for (j=0;j<number-1-i;j++)
            {
                if(stu[j].getChinese()<stu[j+1].getChinese())
                {
                    s=stu[j];
                    stu[j]=stu[j+1];
                    stu[j+1]=s;
                }
            }
        }
    }

    else if(choice1==1&&choice2==2)//����ѡ��
    {
        for(i=0;i<number-1;i++)
        {
            temp=i;
            for(j=i;j<number;j++)
            {
                if(stu[temp].getChinese()<stu[j].getChinese())temp = j;
            }
            if(temp!= i)
            {
                s = stu[temp];
                stu[temp] = stu[i];
                stu[i] = s;
            }
        }
    }

    else if(choice1==2&&choice2==1)//��ѧð��
    {
        for(i=0;i<number-1;i++)
        {
            for(j=0;j<number-1-i;j++)
            {
                if(stu[j].getMath()<stu[j+1].getMath())
                {
                    s=stu[j];
                    stu[j]=stu[j+1];
                    stu[j+1] = s;
                }
            }
        }
    }

    else if(choice1==2&&choice2==2)//��ѧѡ��
    {
        for(i=0;i<number-1;i++)
        {
            temp=i;
            for(int j=i;j<number;j++)
            {
                if (stu[temp].getMath()<stu[j].getMath())temp=j;
            }
            if(temp!= i)
            {
                s = stu[temp];
                stu[temp] = stu[i];
                stu[i] = s;
            }
        }
    }

    else if(choice1==3&&choice2== 1)//Ӣ��ð��
    {
        for(i=0;i<number-1;++i)
        {
            for(j=0;j<number-1-i;j++)
            {
                if(stu[j].getEnglish()<stu[j+1].getEnglish())
                {
                    s = stu[j];
                    stu[j] = stu[j + 1];
                    stu[j + 1] = s;
                }
            }
        }
    }

    else if(choice1==3&&choice2==2)//Ӣ��ѡ��
    {
        for(i=0;i<number-1;i++)
        {
            temp=i;
            for(j=i;j<number;j++)
            {
                if(stu[temp].getEnglish()<stu[j].getEnglish())temp = j;
            }
            if(temp!= i)
            {
                s=stu[temp];
                stu[temp] = stu[i];
                stu[i] = s;
            }
        }
    }

    else if(choice1==4&&choice2==1)//�ܳɼ�ð��
    {
        for(i=0;i<number-1;i++)
        {
            for(j=0;j<number-1-i;j++)
            {
                if(stu[j].getTotal()<stu[j+1].getTotal())
                {
                    s=stu[j];
                    stu[j] = stu[j+1];
                    stu[j+1] = s;
                }
            }
        }
    }

    else if(choice1== 4&&choice2== 2)//�ܳɼ�ѡ��
    {
        for (int i=0; i<number-1;i++)
        {
            temp = i;
            for(int j=i;j<number;j++)
            {
                if(stu[temp].getTotal()<stu[j].getTotal())temp = j;
            }
            if(temp!= i)
            {
                s=stu[temp];
                stu[temp] = stu[i];
                stu[i] = s;
            }
        }
    }

    initial();//����ļ�
    for (int i = 0; i < number; i++)stu[i].append();//д��
    cout << "������ļ���Ϣ���£�" << endl;
    showFile();
    return;
}

void deleteInfo()
{
    ifstream in(filename, ios::in | ios::binary);
    ifstream filein(filename, ios::in | ios::binary);
    fstream out(filename, ios::in | ios::out | ios::binary);
    if (!out||!in)
    {
        cout<<"Error: fail to open the file!"<<endl;
        return;
    }
    char name[30];
    Student stu;
    int number = 0;
    stu.setID(1);
    while(stu.getID()!=0)
    {
        filein.read((char *) &stu, sizeof(Student));
        number++;
    }
    if(number==1)
    {
        cout << "�ļ�������Ϣ��" << endl;
        return;
    }
    cout<<"������Ҫɾ��ѧ����������";
    cin>>name;
    in.seekg(0, ios::beg);
    out.seekg(0, ios::beg);
    stu.setID(1);
    while(stu.getID()!= 0)
    {
        in.read((char *)&stu,sizeof(Student));
        if (!strcmp(stu.getName(),name))
        {
            out.seekp(in.tellg()-long(sizeof(Student)));
            while (true)
            {
                in.read((char *)&stu,sizeof(Student));
                out.write((char *)&stu,sizeof(Student));
                if (stu.getID()==0)
                    break;
            }
            cout<<"ɾ���ɹ���"<<endl;
            break;
        }
        if(stu.getID()==0)cout<<"�Ҳ�������ˣ�"<<endl;
    }

    in.close();
    out.close();

    return;
}

void changeInfo()
{
    ifstream in(filename, ios::in | ios::binary);
    fstream out(filename, ios::in | ios::out | ios::binary);
    if(!out||!in)
    {
        cout<<"Error: fail to open the file!"<<endl;
        return;
    }
    char name[30];
    Student stu;
    stu.setID(1);
    cout<<"������Ҫ�޸ĵ�ѧ��������";
    cin>>name;
    in.seekg(0, ios::beg);
    out.seekg(0, ios::beg);
    while(stu.getID()!=0)
    {
        in.read((char *)&stu,sizeof(Student));
        if (!strcmp(stu.getName(),name))
        {
            cout<<stu<<endl;
            cout<<"��������ĺ����Ϣ��"<<endl;
            stu.input();
            out.seekp(in.tellg() - long(sizeof(Student)));
            out.write((char *)&stu,sizeof(Student));
            cout<<"�޸ĳɹ���"<<endl;
            break;
        }
        if(stu.getID()==0)cout<<"�Ҳ�������ˣ�"<<endl;
    }

    in.close();
    out.close();
    return;
}
