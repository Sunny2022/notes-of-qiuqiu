#include "Student.h"

Student::Student(){setInfo("nobody", 0, 0, 0, 0);}
Student::Student(const char *name, int code, int chniese, int math, int english){
    setInfo(name, code, chniese, math, english);
}

Student::~Student()
{
    //delete []m_name;
    m_name[20]=' ';
}

void Student::setInfo(const char name[30], int ID, int chinese, int math, int english)
{
    setName(name);
    setID(ID);
    setChinese(chinese);
    setMath(math);
    setEnglish(english);
    setTotal();
}

void Student::append()
{
    Student s;
    fstream fileinout("studentInfo", ios::in | ios::out | ios::binary);
    if (!fileinout)
    {
        cout << "Error: fail to open the file!" << endl;
        return;
    }
    do
    {
        fileinout.read((char *) &s, sizeof(Student));
    } while (s.m_ID != 0);

    fileinout.seekp(-long(sizeof(Student)), ios::cur);
    fileinout.write((char *) this, sizeof(Student));
    fileinout.write((char *) &mark, sizeof(Student));

    fileinout.close();
}

const char *Student::getName() const{return m_name;}
void Student::setName(const char *name){strcpy(m_name,name);}
int Student::getID() const{return m_ID;}
void Student::setID(int ID){m_ID = ID;}
int Student::getChinese() const{return m_chinese;}
void Student::setChinese(int chniese){m_chinese = abs(chniese);}
int Student::getMath() const{return m_math;}
void Student::setMath(int math){m_math = abs(math);}
int Student::getEnglish() const{return m_english;}
void Student::setEnglish(int english){m_english = abs(english);}
int Student::getTotal() const{return m_total;}
void Student::setTotal(){m_total=m_math+m_chinese+m_english;}

ostream &operator<<(ostream &output, const Student &s)
{
    output << s.getName() << '\t' << s.getID() << '\t'
           << s.getChinese() << '\t' << s.getMath() << '\t'
           << s.getEnglish() << '\t' << s.getTotal();
    return output;
}

void Student::input()
{
    cout << "����: ";
    cin >>m_name;
    cout << "ѧ��: ";
    cin >>m_ID;
    cout << "���ĳɼ�: ";
    cin >>m_chinese;
    cout << "��ѧ�ɼ�: ";
    cin >>m_math;
    cout << "Ӣ��ɼ�: ";
    cin >>m_english;//�ܳɼ��Զ�����
    setTotal();
    return;
}
Student &Student::operator=(Student s)
{
    setID(s.getID());
    setName(s.getName());
    setChinese(s.getChinese());
    setMath(s.getMath());
    setEnglish(s.getEnglish());
    setTotal();
    return *this;
}
