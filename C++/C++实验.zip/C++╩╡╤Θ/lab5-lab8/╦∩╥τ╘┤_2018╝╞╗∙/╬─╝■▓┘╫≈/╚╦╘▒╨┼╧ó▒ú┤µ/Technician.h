#ifndef TECHNICIAN_H_INCLUDED
#define TECHNICIAN_H_INCLUDED

#include "employee.h"
#define wtime 0

class Technician:public Employee
{
private:
    double m_worktime;
public:
    Technician();
    Technician(const int,const std::string &,const char &,int,int,int,
               double,int post=2);
    ~Technician(){}
    void display() const;

    double getWorktime()const ;
    void setWorktime(double m_worktime);
    void pay();
    void addIntoFile();
};

#endif // TECHNICIAN_H_INCLUDED
