#include "Technician.h"
using namespace std;

Technician::Technician():Employee()
{
    setPost(2);
    setWorktime(0);
    pay();
}

Technician::Technician(const int ID, const string &name, const char &sex, int y, int m, int d, double time,int post)
        : Employee(ID, name, sex, y, m, d, post)
{
    setPost(2);
    setWorktime(time);
    pay();
}

double Technician::getWorktime() const{return m_worktime;}
void Technician::setWorktime(double time){m_worktime = time;}
void Technician::pay(){setSalary(m_worktime*25);}

void Technician::display() const
{
    string sex;
    if(getSex()=='M')sex="��";
    else sex="Ů";
    cout << "\nTechnician��Ϣ��"
         << "\n��ţ�" <<getID()
         << "\n������" <<getName()
         << "\n�Ա�" <<sex
         << "\n�������ڣ�"<<getBirthDate().getYear()
         << "-" <<getBirthDate().getMonth() << "-"
         <<getBirthDate().getDay()
         << "\nְλ��" <<whatPost(Technician::getPost())
         << "\n���ʣ�" <<getSalary()
         << "\n����ʱ��" <<getWorktime()
         << endl;
}

void Technician::addIntoFile(){
    ofstream fileout("������Ա��Ϣ.txt", ios::app);//׷�ӷ�ʽ��
    if (!fileout)
    {
        cout << "open manager failed." << endl;
        return;
    }
    fileout<<getID()<<' '<<getName()<<' '<<getSex()
                  <<' '<<getBirthDate().getYear()<<'-'<<getBirthDate().getMonth()<<'-'<<getBirthDate().getDay()
                  <<' '<<getSalary()<<'\n';
    fileout.close();
}
