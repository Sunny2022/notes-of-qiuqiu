#include "Salesman.h"
using namespace std;

Salesman::Salesman():Employee()
{
    setPost(4);
    setSales(0);
    pay();
}

Salesman::Salesman(double sales, const std::string &department){
    setSales(sales);
    setDepartment(department);
}

Salesman::Salesman(const int ID, const string &name, const char &sex, int y, int m, int d, double sales,
                 const string &department,const int post):Employee(ID, name, sex, y, m, d, post)
{
    setPost(post);
    setSales(sales);
    pay();
    setDepartment(department);
}

void Salesman::pay(){setSalary(getSales()*0.04);}
double Salesman::getSales() const{return m_sales;}
void Salesman::setSales(double sales){m_sales = sales;}
const string &Salesman::getDepartment() const{return m_department;}
void Salesman::setDepartment(const string &department){m_department = department;}

void Salesman::display() const
{
    string sex;
    if(getSex()=='M')sex="��";
    else sex="Ů";
    cout << "\nSalesman��Ϣ��"
         << "\n��ţ�" << getID()
         << "\n������" << getName()
         << "\n�Ա�" << sex
         << "\n��������" << getBirthDate().getYear() << "-"
         <<getBirthDate().getMonth() << "-"
         <<getBirthDate().getDay()
         << "\nְλ��" << whatPost(getPost())
         << "\n���ʣ�" << getSalary()
         << "\n���۶" <<getSales()
         <<"\n�������ţ�"<<getDepartment()
         << endl;
}
void Salesman::addIntoFile(){
    ofstream fileout("����Ա��Ϣ.txt", ios::app);//׷�ӷ�ʽ��
    if (!fileout)
    {
        cout << "open manager failed." << endl;
        return;
    }
    fileout<<getID()<<' '<<getName()<<' '<<getSex()
                  <<' '<<getBirthDate().getYear()<<'-'<<getBirthDate().getMonth()<<'-'<<getBirthDate().getDay()
                  <<' '<<getSalary()<<'\n';
    fileout.close();
}
