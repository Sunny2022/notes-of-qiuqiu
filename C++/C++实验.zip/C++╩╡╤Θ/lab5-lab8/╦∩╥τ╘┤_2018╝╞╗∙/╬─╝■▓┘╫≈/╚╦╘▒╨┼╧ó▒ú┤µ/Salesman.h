#ifndef SALESMAN_H_INCLUDED
#define SALESMAN_H_INCLUDED

#include "employee.h"

class Salesman : virtual public Employee
{
private:
    double m_sales;
    std::string m_department;
public:
    Salesman();
    Salesman(double sales, const std::string &department);
    Salesman(const int,const std::string &,const char &,int,int,int,double,const std::string &,const int post=4);
    ~Salesman(){}
    void display() const;

    void pay();
    double getSales() const;
    void setSales(double sales);
    const std::string &getDepartment() const;
    void setDepartment(const std::string &department);
    void addIntoFile();
};

#endif // SALESMAN_H_INCLUDED
