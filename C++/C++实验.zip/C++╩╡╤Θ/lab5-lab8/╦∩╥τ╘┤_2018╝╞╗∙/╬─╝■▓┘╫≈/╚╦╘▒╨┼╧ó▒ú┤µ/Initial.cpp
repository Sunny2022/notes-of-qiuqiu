#include <fstream>
#include <iostream>
#include <string>
using namespace std;

void Initial(string str[]){
    fstream fileout(str[0],ios::out);
    if (!fileout)cout << "open failed." << endl;
    fileout.close();

    fileout.open(str[1],ios::out);
    if (!fileout)cout << "open failed." << endl;
    fileout.close();

    fileout.open(str[2],ios::out);
    if (!fileout)cout << "open failed." << endl;
    fileout.close();

    fileout.open(str[3],ios::out);
    if (!fileout)cout << "open failed." << endl;
    fileout.close();

}
