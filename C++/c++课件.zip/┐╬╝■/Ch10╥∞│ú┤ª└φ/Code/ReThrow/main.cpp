#include <iostream>
using namespace std;

void trigger()
{
	try
	{
		throw "Warning";
	}
	catch(char *msg)
	{
		cout << "trigger:Catch_" << msg << "_to main" << endl;
		throw;
	}
}

int main()
{
	try
	{
		trigger();
	}
	catch(char * msg)
	{
		cout << "main:_" << msg << "_from trigger" << endl;
	}

	return 0;
}