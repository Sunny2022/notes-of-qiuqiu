#include "iostream"
using namespace std;

int test(char *p,double e,int a)
{
	int f = 1;
	try
	{
		if(*p>='0' && *p<='9')
			throw * p;
		if(e<0 || e>20000)
			throw e;
		if(a<18 || a>70)
			throw a;
	}
	catch(char s)
	{
		f=0;
		cout << "password error: " << s << endl;
	}
	catch(double e)
	{
		f = 0;
		cout << "earnings error: " << e << endl;
	}
	catch(int a)
	{
		f = 0;
		cout << "age error: " << a << endl;
	}
	return f;
}

int main()
{
	char password[8];
	double earnings;
	int age;

	cout << "input password,earnings,age: " << endl;
	cin >> password >> earnings >> age;

	if(test(password,earnings,age))
		cout << password << " " << earnings << " " << age << endl;

	return 0;
}