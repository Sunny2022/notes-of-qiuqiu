#include <iostream>
using namespace std;

template <typename T>
class Array
{
public:
	Array(int s);
	virtual ~Array(){};
protected:
	int size;
	T * element;
};

template <typename T>
Array<T>::Array(int s)
{
	if(s<1)
		throw s;
	else
	{
		size = s;
		element = new T[size];
		if(element==NULL)
			throw (T*)NULL;
	}
}

int main()
{
	int size;
	cin >> size;

	try
	{
		Array <int> IntAry(size);
	}
	catch(int s)
	{
		cout << "size if illegal" << endl;
	}
	catch(int *)
	{
		cout << "Cannot allocate memory" << endl;
	}

	return 0;
}