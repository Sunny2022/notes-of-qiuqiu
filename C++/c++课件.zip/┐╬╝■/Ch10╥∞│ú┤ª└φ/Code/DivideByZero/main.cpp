#include <iostream>
using namespace std;

double Div(double,double);

int main()
{
	double result;

	try
	{
		result = Div(1,2);
		cout << "1 / 2 = " << result << endl;

		result = Div(5,0);
		cout << "5 / 0 = " << result << endl;

		result = Div(10,3);
		cout << "10 / 3 = " << result << endl;
	}
	catch (double e)
	{
		cout << "Divided by double zero" << endl;
		cout << "main function is over." << endl;
	}
	catch(int e)
	{
		cout << "Divided by int zero." << endl;
	}
	catch(...)
	{
		cout << "caught by ..." << endl;
	}

	return 0;
}

double Div(double a,double b)
{
	if (b==0)
		throw 0.0;
	return a/b;
}
