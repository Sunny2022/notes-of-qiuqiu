#include <iostream>
#include <cmath>
#include <exception>
using namespace std;
class DividedByZero: public runtime_error{
public:
    DividedByZero():runtime_error("Divided by zero!"){}
};
float f(float x, float y) noexcept(false){
    if(fabs(y)<1e-6) throw DividedByZero();
    return x/y;
}
int main(){
  try{
      f(10,0);
  }
  catch(DividedByZero& e) {
      cout << e.what() << endl;
  }
  catch(std::exception& e)  {
      //其他的错误
  }
}
