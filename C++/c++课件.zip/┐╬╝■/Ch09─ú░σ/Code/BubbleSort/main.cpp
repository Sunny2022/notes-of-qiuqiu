#include <iostream>
using namespace std;

template <typename ElementType>
void SortBubble(ElementType *a,int size){
	int i,work;
	ElementType temp;
	
	for(int pass =1;pass<size;pass++){
		work = 1;
		for(i=0;i<size-pass;i++){
			if(a[i]>a[i+1]){
				temp = a[i];
				a[i] = a[i+1];
				a[i+1] = temp;
				work = 0;
			}
		}
		if (work) break;
	}
}

int main(){
	int nArr[10];
	float fArr[10];
	int i;

	cout << "Before Sorting" << endl;
	for(i=0;i<10;i++){
		nArr[i] = rand();
		cout << nArr[i] << " ";
	}
	cout << endl;
	for(i=0;i<10;i++){
		fArr[i] = rand();
		cout << fArr[i] << " ";
	}
	cout << endl;

	SortBubble(nArr,10);
	SortBubble(fArr,10);

	cout << "After Sorting" << endl;
	for(i=0;i<10;i++)
		cout << nArr[i] << " ";
	cout << endl;

	for(i=0;i<10;i++)
		cout << fArr[i] << " ";
	cout << endl;

	return 0;
}