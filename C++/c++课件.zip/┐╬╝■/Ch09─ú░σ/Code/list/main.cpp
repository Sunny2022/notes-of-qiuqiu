#include <iostream>
#include <list>
#include <iterator>
using namespace std;

int main(){
	list<int> lI;
	int i;

	for(i=1;i<10;i++)
		lI.push_back(i);
	for(i=10;i<20;i++)
		lI.push_front(i);
	list<int>::iterator iPos;
	for(iPos=lI.begin();iPos!=lI.end();iPos++)
		cout << *iPos << " ";
	cout << endl;

	lI.sort();
	for(iPos=lI.begin();iPos!=lI.end();iPos++)
		cout << *iPos << " ";
	cout << endl;

	return 0;
}