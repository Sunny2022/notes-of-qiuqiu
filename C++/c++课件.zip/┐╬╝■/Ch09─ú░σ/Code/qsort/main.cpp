#include <stdio.h>
#include <stdlib.h>

#define LEN 10

int compare(const void *a,const void *b)
{
	int * aa,*bb;
	aa=(int *)a;
	bb=(int *)b;
	if(*aa>*bb) return 1;
	if(*aa<*bb) return -1;
	return 0;
}

int main()
{
	int arr[LEN];
	int i;
	
	for(i=0;i<LEN;i++)
		arr[i]=rand();
	printf("Before Sorting: ");
	for(i=0;i<LEN;i++)
		printf("%d ",arr[i]);
	printf("\n");

	qsort((void*)arr,size_t(LEN),sizeof(arr[0]),compare);
	printf("After Sorting: ");
	for(i=0;i<LEN;i++)
		printf("%d ",arr[i]);
	printf("\n");

	return 0;
}
