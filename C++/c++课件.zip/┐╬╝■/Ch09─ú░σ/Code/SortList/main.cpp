#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <list>
#include <iterator>
using namespace std;

void createList(list<int> &,int);
void outList(list<int> &);
void inorderMerge(list<int>&,const list<int>,const list<int>);

int main(){
	list<int> L1,L2,L;
	list<int>::iterator p;

	srand(time(0));
	createList(L1,10);
	cout << "List L1: " << endl;
	outList(L1);

	createList(L2,5);
	cout << "List L2: " << endl;
	outList(L2);

	inorderMerge(L,L1,L2);
	cout << "list L: " << endl;
	outList(L);

	return 0;
}

void createList(list<int> &orderList,int len){
	list<int>::iterator p;
	int i,k;

	for(i=0;i<len;i++){
		k = rand() % 100;
		p = orderList.begin();
		while(*p < k && p!=orderList.end())
			p++;
		orderList.insert(p,k);
	}
}

void outList(list<int> &List){
	list<int>::iterator p;
	p = List.begin();
	while(p!=List.end()){
		cout << *p << " ";
		p++;
	}
	cout << endl;
}

void inorderMerge(list<int>& L,const list<int> L1,const list<int> L2){
	list<int>::const_iterator p,q;
	p = L1.begin();
	q = L2.begin();

	while(p!=L1.end() && q!=L2.end()){
		if(*p < *q){
			L.push_front(*p);
			p++;
		}
		else{
			L.push_front(*q);
			q++;
		}
	}
	while(p!=L1.end()){
		L.push_front(*p);
		p++;
	}
	while(q!=L2.end()){
		L.push_front(*q);
		q++;
	}
}