#include <iostream>
#include <vector>
#include <iterator>
#include <algorithm>
using namespace std;

bool greaterthan10(int value){
	return value > 10;
}

int main(){
	vector<int> vctI;
	vector<int>::iterator iPos;

	vctI.push_back(1);
	vctI.push_back(100);
	vctI.push_back(25);
	vctI.push_back(18);
	vctI.push_back(56);
	vctI.push_back(87);

	iPos=find(vctI.begin(),vctI.end(),25);
	cout << *iPos << endl;
	iPos=find_if(vctI.begin(),vctI.end(),greaterthan10);
	cout << *iPos << endl;

	return 0;
}