#ifndef _LINKLIST_H_
#define _LINKLIST_H_

class LINKLIST{
	struct NODE{
		int i;
		NODE * next;
	}*head;
public:
	LINKLIST();
	LINKLIST(LINKLIST &);
	~LINKLIST();

	void Create();
	void Insert(int i);
	void Remove(int i);
	NODE * Find(int i);
};

#endif