#include "iostream.h"
#include "Linklist.h"

int main(){

	return 0;
}