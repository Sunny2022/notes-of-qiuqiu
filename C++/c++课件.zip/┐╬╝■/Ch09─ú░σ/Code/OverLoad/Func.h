#ifndef _FUNC_H_
#define _FUNC_H_

int abs(int);
double abs(double);
long abs(long);

#endif