#include "func.h"
#include <iostream.h>

int main(){
	cout << abs(-10) << ends 
		 << abs(-10.5) << ends
		 << abs(-1000000) << endl;

	return 0;
}