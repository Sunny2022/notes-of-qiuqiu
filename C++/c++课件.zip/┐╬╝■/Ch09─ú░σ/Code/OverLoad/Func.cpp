#include "func.h"

int abs(int x){
	return x>0?x:-x;
}

double abs(double x){
	return x>0?x:-x;
}

long abs(long x){
	return x>0?x:-x;
}