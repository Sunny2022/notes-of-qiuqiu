#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

bool Descending(int a,int b){
	return a>b;
}

int main(){
	vector<int> vctI;
	int i;

	for(i=1;i<=10;i++)
		vctI.push_back(i);
	for(i=11;i<=20;i++)
		vctI.insert(vctI.begin(),i);

	cout << "Not Sorted: ";
	vector<int>::iterator iPos;
	for(iPos=vctI.begin();iPos!=vctI.end();iPos++)
		cout << *iPos << " ";
	cout << endl;

	//升序排
	cout << "Sorted Ascending: ";
	sort(vctI.begin(),vctI.end());
	for(iPos=vctI.begin();iPos!=vctI.end();iPos++)
		cout << *iPos << " ";
	cout << endl;

	//降序排
	cout << "Sorted Descending: ";
	sort(vctI.begin(),vctI.end(),Descending);
	for(iPos=vctI.begin();iPos!=vctI.end();iPos++)
		cout << *iPos << " ";
	cout << endl;

	//折半查找
	if(binary_search(vctI.begin(),vctI.end(),15,Descending))
		cout << 15 << " exists in vector" << endl;
	else cout << 15 << " not exists ing vector" << endl;
	

	return 0;
}