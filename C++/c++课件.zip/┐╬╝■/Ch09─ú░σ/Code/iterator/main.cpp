#include <iostream>
#include <vector>
#include <iterator>
using namespace std;

int main(){
	vector<int> vI;
	int i;

	for(i=1;i<=20;i++)
		vI.push_back(i);

	//using const_iterator
	cout << "using const_iterator:" << endl;
	vector<int>::const_iterator icfPos;
	icfPos=vI.begin();
	for(;icfPos!=vI.end();icfPos++)
		cout << *icfPos << " ";
	cout << endl;

	//using iterator
	cout << "using iterator:" << endl;
	vector<int>::iterator ifPos;
	ifPos=vI.begin();
	for(;ifPos!=vI.end();ifPos++){
		*ifPos=*ifPos*2;
		cout << *ifPos << " ";
	}
	cout << endl;

	//using reverse_iterator
	cout << "using reverse_iterator:" << endl;
	vector<int>::reverse_iterator irPos;
	irPos=vI.rbegin();
	for(;irPos!=vI.rend();irPos++){
		*irPos=*irPos / 2 ;
		cout << *irPos << " ";
	}
	cout << endl;

	return 0;
}