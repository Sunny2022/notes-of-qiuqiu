#include <iostream>
#include <vector>
using namespace std;

int main(){
	vector<int> vI;
	int i;

	//用作数组——动态数组：其长度可调
	cout << "using as dynamic array" << endl;
	vI.resize(10);   //将数组长度设为10   //vI.reserve(1000);
	for(i=0;i<8;i++)
		vI[i]=i;
	for(i=0;i<8;i++)
		cout << vI[i] << " " ;
	cout << endl;
	cout << vI.capacity() << endl;

	//用作栈：
	cout << "using as stack:" << endl;
	vector<double> vD;
	for (i=1;i<=100;i++)
		vD.push_back(i);
	for(;!vD.empty();){
		cout << vD.back() << " ";
		vD.pop_back();
	}
	cout << endl;

	//用作队列
	cout << "using as queue:" <<endl;
	vector <float> vF;
	for(i=1;i<20;i++)
		vF.push_back(i);
	for(;!vF.empty();){
		cout << vF.front() << " ";
		vF.erase(vF.begin());
	}
	cout << endl;

	return 0;
}
