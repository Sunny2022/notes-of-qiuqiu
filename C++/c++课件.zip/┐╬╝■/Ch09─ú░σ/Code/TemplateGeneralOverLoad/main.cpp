#include <iostream>
using namespace std;

template <typename T> 
T Max(T a,T b){                    
	return a>b?a:b;    
}                   
char* Max(char *a,char *b){
	if (strcmp(a,b)>0) return a;
    else return b;
}

int main(){
	cout << Max(12,120) << endl;
	cout << Max(12.5,120.5) << endl;

	cout << Max("ABCDE","abcde") << endl;

	return 0;
}