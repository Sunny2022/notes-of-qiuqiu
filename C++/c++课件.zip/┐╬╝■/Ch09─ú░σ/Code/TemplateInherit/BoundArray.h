#ifndef _BOUNDARRAY_H_
#define _BOUNDARRAY_H_
#include "Array.h"

template <typename T>
class BoundArray:public Array<T>{
public:
	BoundArray(int low=0,int height=1);
	virtual const T& Entry(int index)const;
	virtual void Enter(int index,const T& value);
private:
	int min;
};

template <typename T>
BoundArray<T>::BoundArray(int low,int height):Array<T>(height-low+1){
	if(height - low < 0){
		cout << "Beyond the bounds of Array." << endl;
		exit(1);
	}
	min = low;
}

template <typename T>
const T& BoundArray<T>::Entry(int index) const{
	if(index < min || index > min+size-1){
		cout << "Beyond the bounds of index." << endl;
		exit(1);
	}
	return Array<T>::Entry(index - min);
}

template <typename T>
void BoundArray<T>::Enter(int index,const T& value){
	if(index < min || index > min+size-1){
		cout << "Beyond the bounds of index." << endl;
		exit(1);
	}
	Array<T>::Enter(index - min,value);
}

#endif