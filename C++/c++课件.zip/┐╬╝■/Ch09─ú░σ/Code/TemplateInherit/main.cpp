#include <iostream>
#include "BoundArray.h"
using namespace std;

int main(){
	int i;
	int low = 1,height = 10;
	BoundArray<int> b(low,height);

	for(i=low;i<=height;i++)
		b.Enter(i,i*2);
	cout << "BoundArray: " << endl;
	for(i=low;i<=height;i++){
		cout << "b[" << i << "]=" << b.Entry(i) << "\t" ;
		if(i%5==0)
			cout << endl;
	}

	return 0;
}