#pragma warning (disable:4786)

#include <iostream>
#include <string>
#include <queue>
using namespace std;

int main(){
	queue<string> q;
	string str;

	q.push("cat");
	q.push("dog");
	q.push("pig");
	q.push("rabbit");
	q.push("tiger");
	q.push("lion");

	while(!q.empty()){
		str=q.front();
		cout << str << " ";
		q.pop();
	}
	cout << endl;

	return 0;
}