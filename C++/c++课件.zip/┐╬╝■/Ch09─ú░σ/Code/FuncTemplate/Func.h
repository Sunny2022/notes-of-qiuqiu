#ifndef _FUNC_H_
#define _FUNC_H_ 

template <class T>
T Tabs(T x){
	return x>0?x:-x;
}

template <class T>
T Max(T x,T y){
	if (x>y)
		return x;
	else 
		return y;
}

#endif