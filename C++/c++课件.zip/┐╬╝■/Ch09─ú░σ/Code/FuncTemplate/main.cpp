#include "func.h"
#include <iostream>
using namespace std;

int main(){
	cout << Tabs(10) << endl;
		 << Tabs(-10.5) << endl;
		 << Tabs(-1000000) << endl;

	cout << Max(10,20) << endl;
	cout << Max(10.0,20.0) << endl;
	cout << Max('A','B') << endl;

	return 0;
}