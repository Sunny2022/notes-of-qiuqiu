#include <iostream>
using namespace std;

template <typename T>
T Max(T a,T b){ 
	return a>b?a:b;
}

template <typename T>
T Max(T a,T b,T c){
	return a>b?(a>c?a:c):(b>c?b:c);
}

int main(){
	cout << Max(12,120) << endl;
	cout << Max(10.0,100.0) << endl;

	cout << Max(12,120,1200) << endl;
	cout << Max(10.0,100.0,1000.0) << endl;

	return 0;
}