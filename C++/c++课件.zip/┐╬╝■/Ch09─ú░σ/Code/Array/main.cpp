#include <iostream>
#include "Array.h"

using namespace std;

int main(){
	Array<int> IntAry(5);
	int i;

	for(i=0;i<5;i++)
		IntAry.Enter(i,i);
	cout << "Integer Array:\n";
	for(i=0;i<5;i++)
		cout << IntAry.Entry(i) << '\t';
	cout << endl;
	Array<double> DouAry(5);
	for(i=0;i<5;i++)
		DouAry.Enter(i,(i+1)*0.35);
	cout << "Double Array: \n";
	for(i=0;i<5;i++)
		cout << DouAry.Entry(i) << '\t';
	cout << endl;

	return 0;
}