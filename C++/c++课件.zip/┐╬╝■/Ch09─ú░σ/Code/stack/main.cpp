#include <iostream>
#include <stack>
using namespace std;

int main(){
	stack<int> s;
	int i,x;

	for(i=1;i<=20;i++)
		s.push(i);
	cout << "element number: " << s.size() << endl; 

	//��ջ����
	for(;!s.empty();){
		x=s.top();
		cout << x << " ";
		s.pop();
	}
	cout << endl;
	
	return 0;
}