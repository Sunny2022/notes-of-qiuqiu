#include "iostream.h"

template <class T>
class LinkList{
	struct NODE{
		T i;
		NODE * next;
	}*head;
public:	
	LinkList();
	LinkList(LinkList & llst)
	~LinkList()

	void Create();
	void Insert(T & tVal);
	void Remove(T & tVal);
	NODE * Find(T & tVal);
};