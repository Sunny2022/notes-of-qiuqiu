#include "ClsTemplate.h"

int main()
{


	return 0;
}