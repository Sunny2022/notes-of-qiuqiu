#include <iostream>
using namespace std;

class CCountObj{
	static int count;
public:
	CCountObj(){
		count++;
	}
	static int getCount(){
		return count;
	}
};

int CCountObj::count=0;

int main(){
	cout << "Object number: " << CCountObj::getCount() << endl;

	CCountObj obj1;
	cout << "Object number: " << CCountObj::getCount() << endl;

	CCountObj obj2=obj1;
	cout << "Object number: " << CCountObj::getCount() << endl;

	return 0;
}
