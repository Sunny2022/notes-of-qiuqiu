#ifndef _ACCOUNT_H_
#define _ACCOUNT_H_

class Account {
	char sName[32];
	char sID[32];
	float fBalance;
public:
	Account(char *, char *, float);
	void deposit(float amount);
	bool withdraw(float amount);
	float getBalance()const;
};

#endif