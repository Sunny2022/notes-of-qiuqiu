#include "Account.h"
#include <iostream>
using namespace std;

int main() {
	Account acc("张三", "S980001", 1000);

	acc.deposit(1000);
	acc.withdraw(500);
	cout << acc.getBalance() << endl;

	return 0;
}
