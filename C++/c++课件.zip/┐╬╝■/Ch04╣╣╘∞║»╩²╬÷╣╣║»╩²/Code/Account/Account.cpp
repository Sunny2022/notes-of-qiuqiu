#include "Account.h"
#include <string.h>

Account::Account(char *name, char *id, float amount) {
	strcpy(sName, name);
	strcpy(sID, id);
	fBalance = amount;
}

void Account::deposit(float amount) {
	fBalance += amount;
}

bool Account::withdraw(float amount) {
	if (amount > fBalance)
		return false;
	fBalance -= amount;
	return true;
}

float Account::getBalance()const {
	return fBalance;
}
