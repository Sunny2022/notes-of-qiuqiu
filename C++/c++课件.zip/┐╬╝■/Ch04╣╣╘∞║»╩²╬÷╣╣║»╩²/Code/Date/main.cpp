#include "Date.h"
#include <iostream>
using namespace std;

int main()
{
	Date dtObj(2004,10,11);
	Date dtObjDft;

	return 0;
}
