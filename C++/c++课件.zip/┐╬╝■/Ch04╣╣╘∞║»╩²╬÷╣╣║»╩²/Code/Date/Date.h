#ifndef _DATE_H_
#define _DATE_H_

class Date
{
	int year,month,day;
public:
	Date();
	Date(int,int,int);
	void setDate(int y,int m,int d);
	bool isLeapYear()const;
	void PrintDate()const;
};

#endif