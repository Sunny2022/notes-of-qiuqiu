#include "Date.h"
#include <iostream>
using namespace std;

Date::Date()
{
	year=0;month=0;day=0;
	// cout << "Date object initialized." << endl;
}

Date::Date(int y,int m,int d)
{
	year=y;
	month=m;
	day=d;
	// cout << year << "/" << month << "/" << day << " :Date object initialized." << endl;
}

void Date::setDate(int y,int m,int d)
{
	year=y;
	month=m;
	day=d;
}

bool Date::isLeapYear() const
{
	return year %4==0 && year%100!=0 || year%400==0;
}

void Date::PrintDate() const
{
	cout << year << "/" << month << "/" << day << endl;
}