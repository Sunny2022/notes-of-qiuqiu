// PtrMembRight.cpp : Defines the entry point for the console application.
//
#include <iostream>
#include <string.h>
using namespace std;

class Name{
	char *pname;
	int size;
public:
	Name(char *pn)	{
		if(pn==NULL)
			return;
		size=strlen(pn);
		pname=new char[size+1];
		strcpy(pname,pn);
	}
	Name(const Name & nm)	{
		size=nm.size;
		if(nm.pname!=NULL)
		{
			pname=new char[size+1];
			strcpy(pname,nm.pname);
		}

	}
	~Name()
	{
		if(pname!=NULL)
		{
			delete []pname;
			pname=nullptr;
			size=0;
		}
	}
};

int main(int argc, char* argv[])
{
	Name a("张三");
	Name b(a);

	return 0;
}
