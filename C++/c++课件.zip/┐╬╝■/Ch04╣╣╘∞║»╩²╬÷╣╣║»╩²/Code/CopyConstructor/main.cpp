#include <iostream>
using namespace std;

class A {
public:
	A(int) {
		cout << "A()" << endl;
	}
	A(const A&) {
		cout << "A(A&,int)" << endl;
	}
};

int main() {
	A a(1);
	A b(a);
	A c = b;

	return 0;
}
