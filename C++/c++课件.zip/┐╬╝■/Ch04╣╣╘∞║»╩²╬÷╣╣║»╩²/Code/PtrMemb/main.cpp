#include <iostream>
#include <string.h>
using namespace std;

class name{
	char *pname;
	int size;
public:
	name(char *pn){
		if(pn==NULL)
			return;
		size=strlen(pn)+1;
		pname=new char[size];
		strcpy(pname,pn);
	}
	~name(){
		if(pname!=NULL){
			delete []pname;
			pname=nullptr;
			size=0;
		}
	}
};

int main(){
	name Obj1("张三");
	name Obj2(Obj1);

	return 0;
}
