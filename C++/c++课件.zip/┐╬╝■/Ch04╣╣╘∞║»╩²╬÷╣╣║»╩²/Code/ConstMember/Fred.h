#ifndef _FRED_H_
#define _FRED_H_

class Fred {
	const int size;
	int x;
public:
	Fred();
	Fred(int sz, int xx);
	void print();
};

#endif