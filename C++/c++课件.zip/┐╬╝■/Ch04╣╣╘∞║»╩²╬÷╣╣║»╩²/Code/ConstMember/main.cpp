#include "Fred.h"
#include <iostream>
using namespace std;
int main() {
	Fred fdObj;
	fdObj.print();
	cout << endl;

	Fred fdObj2(100,10);
	fdObj2.print();
	cout << endl;

	return 0;
}
