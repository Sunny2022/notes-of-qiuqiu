#include "Fred.h"
#include <iostream>
using namespace std;

Fred::Fred(): size(0) {
	x = 0;
}

Fred::Fred(int sz, int xx): size(sz) {
	x = xx;
}

void Fred::print() {
	cout << size;
}
