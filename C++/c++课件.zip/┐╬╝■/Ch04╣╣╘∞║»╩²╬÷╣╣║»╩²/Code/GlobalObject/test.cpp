#include <iostream>
using namespace std;

class CDemo{
public:
	CDemo(){cout << "This is in CDemo()" << endl 
		<< "put the code to complete the construction task here" 
		<< endl << endl;}
	~CDemo(){cout << "This is in ~CDemo()" << endl
		<< "put the code complete the release task here" 
		<< endl << endl;}
};

CDemo gObj;
int main(){
	cout << "this is the sole output statement of the function main()" 
		<< endl << endl;

	return 0;
}