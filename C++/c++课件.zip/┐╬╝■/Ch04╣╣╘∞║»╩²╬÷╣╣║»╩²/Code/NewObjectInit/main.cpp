#include <iostream>
using namespace std;

class Location{
	int x,y;
public:
	Location(int xx=0,int yy=0);
	Location(const Location & p);
	int getX(){return x;}
	int getY(){return y;}
};

Location::Location(int xx,int yy){
	x=xx;
	y=yy;
	// cout << "Location()" << endl;
}

Location::Location(const Location &p){
	x=p.x;
	y=p.y;
	// cout << "Loaction(Location &)" << endl;
}

void f(Location p){
	cout << "Function:" << p.getX() << "," << p.getY() <<endl;
}
Location g(){
	Location A(1,2);
	return A;
}

int main(){
	Location A(1,2);
	Location B(A);

	cout << "B:" << B.getX() << "," << B.getY() << endl;

	f(A);
	g();

	return 0;
}
