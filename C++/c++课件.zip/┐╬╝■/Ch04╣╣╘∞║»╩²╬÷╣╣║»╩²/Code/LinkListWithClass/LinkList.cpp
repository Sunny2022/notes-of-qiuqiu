#include "LinkList.h"
#include <iostream>
using namespace std;

LinkList::LinkList()
{
	head=new NODE;
	head->next=NULL;
	do
	{
		char ch;
		cin >> ch;
		if(ch=='@')
			break;
		NODE *p1=new NODE;
		p1->ch=ch;
		p1->next=head->next;
		head->next=p1;
	} while(true);
}

bool LinkList::Insert(int i,char ch)
{
	int nCount=1;
	NODE *pWork,*pNew;
	pWork=head;
	while(nCount<=i)
	{
		pWork=pWork->next;
		if (pWork==NULL)
			return false;
		nCount++;
	}
	pNew=new NODE;
	pNew->ch=ch;

	pNew->next=pWork->next;
	pWork->next=pNew;

	return true;
}

bool LinkList::Delete(int i)
{
	NODE *pWork=head,*pPre=NULL;
	int nCount=1;

	while(nCount<=i)
	{
		pPre=pWork;
		pWork=pWork->next;
		if (pWork==NULL)
			return false;
		nCount++;
	}
	pPre->next=pWork->next;
	delete pWork;

	return true;
}

bool LinkList::Delete(char ch)
{
	NODE *pWork=head->next,*pPre=NULL;
	int nCount=1;

	while(pWork!=NULL && pWork->ch!=ch)
	{
		pPre=pWork;
		pWork=pWork->next;
	}
	if (pWork==NULL)
		return false;
	pPre->next=pWork->next;
	delete pWork;

	return true;
}

LinkList::~LinkList()
{
	NODE *pWork;
	while(head!=NULL)
	{
		pWork=head;
		head=head->next;
		delete pWork;
	}
}

void LinkList::Display()
{
	NODE*pWork=head->next;

	while(pWork!=NULL)
	{
		cout << pWork->ch << ends;
		pWork=pWork->next;
	}
	cout << endl;
}
