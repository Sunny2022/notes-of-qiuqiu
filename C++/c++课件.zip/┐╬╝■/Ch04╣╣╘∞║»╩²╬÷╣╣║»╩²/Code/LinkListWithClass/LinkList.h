#ifndef _LINKLIST_H_
#define _LINKLIST_H_

class LinkList
{
private:
	struct NODE
	{
		char ch;
		struct NODE *next;
	}*head;
public:
	LinkList();
	~LinkList();
	bool Insert(int,char);
	bool Delete(int);
	bool Delete(char);
	void Display();
};

#endif