#ifndef _CIRCLE_H_
#define _CIRCLE_H_
#include "Point.h"

class Circle {
	Point ptCenter;
	int nRadius;
public:
	Circle();
	Circle(int x, int y, int r);
	Circle(Point &pt, int r);
	Circle(const Circle & c);
	void Print();
	int getRadius()const;
};

#endif