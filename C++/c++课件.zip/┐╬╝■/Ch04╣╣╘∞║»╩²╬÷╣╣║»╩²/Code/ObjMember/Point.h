#ifndef _POINT_H_
#define _POINT_H_

class Point {
	int x, y;
public:
	Point();
	Point(int xx, int yy);
	
	void moveTo(int xx, int yy);
	int getX()const;
	int getY()const;
};

#endif