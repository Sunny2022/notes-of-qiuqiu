#include "Point.h"

Point::Point() {
	x = 0;
	y = 0;
}

Point::Point(int xx, int yy) {
	x = xx;
	y = yy;
}

void Point::moveTo(int xx, int yy) {
	x = xx;
	y = yy;
}

int Point::getX()const {
	return x;
}

int Point::getY()const {
	return y;
}