#include "Circle.h"
#include <iostream>
using namespace std;

Circle::Circle(): ptCenter(0, 0) {
	nRadius = 0;
}

Circle::Circle(int x, int y, int r): ptCenter(x, y) {
	nRadius = r;
}

Circle::Circle(Point &pt, int r): ptCenter(pt) {
	nRadius = r;
}

Circle::Circle(const Circle & c): ptCenter(c.ptCenter.getX(), c.ptCenter.getY())
		//此处也可以：CirCle::Circle(const Circle & c):ptCenter(c.ptCenter)
{
	nRadius = c.nRadius;
}

int Circle::getRadius()const {
	return nRadius;
}

void Circle::Print() {
	cout << "Center: (" << ptCenter.getX() << "," << ptCenter.getY() << ")" << endl;
	cout << "Radius: " << nRadius << endl;
}