#include <iostream>
#include "Point.h"
#include "Circle.h"
using namespace std;

int main() {
	Point pt(10, 10);
	Circle cle(100, 100, 10);
	Circle cl(pt, 100);

	cle.Print();
	cl.Print();

	return 0;
}
