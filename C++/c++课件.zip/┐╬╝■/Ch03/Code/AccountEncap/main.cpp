#include <iostream>
#include "Account.h"

using namespace std;

int main() {
	Account acc;

	acc.initialize("张三", "s980012", 500);
	acc.deposit(500);
	acc.withdraw(300);

	cout << acc.get_balance() << endl;

	return 0;
}
