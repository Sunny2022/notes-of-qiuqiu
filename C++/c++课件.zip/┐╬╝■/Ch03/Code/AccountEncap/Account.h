#ifndef _ACCOUNT_H_
#define _ACCOUNT_H_

struct Account {
	char sName[20];
	char sID[20];
	float fBalance;
	
	void initialize(char *, char *, float);
	void deposit(float);
	bool withdraw(float);
	float get_balance();
};

#endif