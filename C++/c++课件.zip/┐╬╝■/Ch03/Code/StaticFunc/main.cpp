#include <iostream>
using namespace std;

class X
{
	int DatMem;
public:
	static void StaFun(int i,X* ptr)
	{
//		DatMem=i;
		ptr->DatMem=i;
	}
};

int main()
{
	X obj;
	obj.StaFun(10,&obj);
	X::StaFun(1,&obj);

	return 0;
}
