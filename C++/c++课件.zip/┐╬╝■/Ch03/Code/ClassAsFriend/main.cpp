#include <iostream>
#include "Demo.h"
using namespace std;

int main()
{
	B bObject;
	A aObject;

	bObject.Set(aObject,100);
	bObject.Display(aObject);

	return 0;
}