#ifndef _DEMO_H_
#define _DEMO_H_

class A
{
	friend class B;
public:
	void Display();
private:
	int x;
};

class B
{
public:
	void Set(A &aObject,int i);
	void Display(A & AObject);
};

#endif