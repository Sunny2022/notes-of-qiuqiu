#include <iostream>
#include "Demo.h"

using namespace std;

void A::Display()
{
	cout << x << endl;
}

void B::Set(A &aObject,int i)
{
	aObject.x=i;
}

void B::Display(A &aObject)
{
	aObject.Display();
}
