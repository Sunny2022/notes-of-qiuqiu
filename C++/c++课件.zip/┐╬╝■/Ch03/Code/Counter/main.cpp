#include "Counter.h"
#include <iostream>
using namespace std;

int main()
{
	int i;
	counter a;

	for(i=0;i<5;i++)
	{
		a.num+=1;
		cout << counter::num << '\t';
	}
	cout << endl;

	return 0;
}
