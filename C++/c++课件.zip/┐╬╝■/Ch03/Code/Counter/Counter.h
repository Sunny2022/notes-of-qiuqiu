#ifndef _COUNTER_H_
#define _COUNTER_H_

class counter
{
public:
	static int num;
	void setnum(int i);
	void shownum();
};

#endif