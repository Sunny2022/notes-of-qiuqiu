#ifndef _CONSTMEMBFUNC_H_
#define _CONSRMEMBERFUNC_H_

class ConstMembFunc
{
	int x;
public:
	void setX(const int xx);
	int getX()const;
};

#endif