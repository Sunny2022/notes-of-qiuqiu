#include "ConstMembFunc.h"
#include <iostream>
using namespace std;

int main()
{
	ConstMembFunc Obj;

	Obj.setX(100);
	cout << Obj.getX() << endl;

	return 0;
}
