#include "ConstMembFunc.h"

void ConstMembFunc::setX(const int xx)
{
	x=xx;
}

int ConstMembFunc::getX()const
{
	return x;
}
