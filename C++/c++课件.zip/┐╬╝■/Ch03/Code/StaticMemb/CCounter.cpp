#include "Counter.h"
#include <iostream>
using namespace std;

int counter::num=0;
void counter::setnum(int i)
{
	num = i;
}
void counter::shownum()
{
	cout << num << '\t'; 
}
