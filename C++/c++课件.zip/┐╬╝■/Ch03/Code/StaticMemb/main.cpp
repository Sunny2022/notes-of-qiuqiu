#include "Counter.h"
#include <iostream>
using namespace std;
//*/
int main()
{
	counter a,b;
	a.shownum(); b.shownum();
	a.setnum(10); 
	a.shownum(); b.shownum();
	cout << endl;

	return 0;
}
