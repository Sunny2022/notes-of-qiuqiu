#ifndef _COUNTER_H_
#define _COUNTER_H_

class counter
{
	static int num;
public:
	void setnum(int i);
	void shownum();
};

#endif