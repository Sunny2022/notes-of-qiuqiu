#include <iostream>
#include "Demo.h"

using namespace std;

void A::Display()
{
	cout << x << endl;
}

void B::set(int i)
{
	AObject.x=i;
}

void B::Display()
{
	AObject.Display();
}