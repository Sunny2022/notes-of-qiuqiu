#ifndef _DEMO_H_
#define _DEMO_H_

class A
{
	friend class B;
public:
	void Display();
private:
	int x;
};

class B
{
public:
	void set(int i);
	void Display();
private:
	A AObject;
};

#endif