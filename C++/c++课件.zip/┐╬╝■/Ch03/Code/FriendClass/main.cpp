#include <iostream>
#include "Demo.h"
using namespace std;

int main()
{
	B BObject;

	BObject.set(100);
	BObject.Display();

	return 0;
}