#include "Account.h"
#include <string.h>

void Account::Initialize(char *name,char *id,float amount){
	strcpy(sName,name);
	strcpy(sID,id);
	fBalance=amount;
}

void Account::Deposit(float amount){  //往帐户中存钱
	fBalance+=amount;
}

bool Account::Withdraw(float amount){  //取钱
	if(amount > fBalance)
		return false;            //不允许透支

	fBalance-=amount;
	return true;
}

float Account::Get_balance(){   //查看帐户中的钱
	return fBalance;
}
