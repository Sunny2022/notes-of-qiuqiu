#ifndef _ACCOUNT_H_
#define _ACCOUNT_H_

class Account
{
private:
	char sName[20];
	char sID[20];
	float fBalance;
public:
	void Initialize(char *,char *,float);
	void Deposit(float);
	bool Withdraw(float);
	float Get_balance();	
};

#endif