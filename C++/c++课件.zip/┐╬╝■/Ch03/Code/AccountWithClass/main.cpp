#include <iostream>
#include "Account.h"

using namespace std;

int main(){
	Account acc,acc2;

	acc.Initialize("张三","s980012",500);

	acc.Deposit(500);
	acc.Withdraw(300);

	cout << acc.Get_balance() << endl;

	acc2.Initialize("skfj","kskdjf",50000);
	acc2.Deposit(2000);

	return 0;
}
