#include "Fred.h"

int main()
{
	Fred fredObj(100);
	fredObj.Print();

	return 0;
}