#ifndef _FRED_H_
#define _FRED_H_

class Fred
{
	const int size;
public:
	Fred(int sz);
	void Print();
};

#endif