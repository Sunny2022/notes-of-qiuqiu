#include "Fred.h"
#include <iostream>
using namespace std;

Fred::Fred(int sz):size(sz){}

void Fred::Print()
{
	cout << size;
}
