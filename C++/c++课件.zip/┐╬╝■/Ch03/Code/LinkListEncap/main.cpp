#include <iostream>
#include "LinkList.h"

using namespace std;

int main(){
	LinkList lst;

	lst.Initialize();
	lst.Display();
	lst.Insert(2,'X');
	lst.Display();
	lst.Delete('c');
	lst.Display();

	return 0;
}