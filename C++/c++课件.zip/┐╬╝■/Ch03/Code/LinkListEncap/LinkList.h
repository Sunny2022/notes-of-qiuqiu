#ifndef _LINKLIST_H_
#define _LINKLIST_H_

struct LinkList{
	struct NODE{
		char ch;
		struct NODE *next;
	}*head;

	void Initialize();
	bool Insert(int,char);
	bool Delete(int);
	bool Delete(char);
	void Cleanup();
	void Display();
};

#endif
