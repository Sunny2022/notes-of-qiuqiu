#include "LinkList.h"
#include <iostream>
using namespace std;

void LinkList::Initialize(){
	head=new NODE;
	head->next=NULL;
	do{
		char ch;
		cin >> ch;
		if(ch=='@')
			break;
		NODE *p1=new NODE;
		p1->ch=ch;
		p1->next=head->next;
		head->next=p1;
	} while(true);
}

bool LinkList::Insert(int i,char ch){
	int nCount=1;
	NODE *pWork,*pNew;
	pWork=head;
	while(nCount<=i){
		pWork=pWork->next;
		if (pWork==NULL)
			return false;
		nCount++;
	}
	pNew=new NODE;
	pNew->ch=ch;

	pNew->next=pWork->next;
	pWork->next=pNew;

	return true;
}

bool LinkList::Delete(int i){
	NODE *pWork=head->next,*pPre=head;
	int nCount=1;

	while(pWork!=NULL && nCount<i){
		pPre=pWork;
		pWork=pWork->next;
		nCount++;
	}
	if(pWork!=NULL){
		pPre->next=pWork->next;
		delete pWork;
		return true;
	}
	return false;
}

bool LinkList::Delete(char ch){
	NODE *pWork=head->next,*pPre=head;
	int nCount=1;

	while(pWork!=NULL && pWork->ch!=ch){
		pPre=pWork;
		pWork=pWork->next;
	}
	if (pWork==NULL)
		return false;
	pPre->next=pWork->next;
	delete pWork;

	return true;
}

void LinkList::Cleanup(){
	NODE *pWork;
	while(head!=NULL){
		pWork=head;
		head=head->next;
		delete pWork;
	}
}

void LinkList::Display(){
	NODE*pWork=head->next;

	while(pWork!=NULL){
		cout << pWork->ch << ends;
		pWork=pWork->next;
	}
	cout << endl;
}
