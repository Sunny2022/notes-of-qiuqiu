#include <iostream>
#include "Demo.h"
using namespace std;

int main()
{
	A aObj;
	B bObj;

	aObj.mFuncOfA(bObj,10,100);
	cout << "bObj.x = " << bObj.getX() << endl
		 << "bObj.y = " << bObj.getY() << endl;

	return 0;
}
