#include "Demo.h"

void A::mFuncOfA(B &bObj,int x,int y)
{
	bObj.x=x;
	bObj.y=y;
}

int B::getX(){return x;}
int B::getY(){return y;}
