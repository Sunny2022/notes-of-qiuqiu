#ifndef _DEMO_H_
#define _DEMO_H_

class B;

class A
{
public:
	void mFuncOfA(B &bObj,int x,int y);
};

class B
{
	int x,y;
public:
	int getX();
	int getY();
	friend void A::mFuncOfA(B&,int,int);
};

#endif