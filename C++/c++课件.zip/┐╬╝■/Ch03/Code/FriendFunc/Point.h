#ifndef _POINT_H_
#define _POINT_H_

class Point
{
	double X,Y;
public:
	void setX(double x);
	void setY(double y);
	double getX();
	double getY();
	friend double Distance(Point &a,Point &b);
};

#endif