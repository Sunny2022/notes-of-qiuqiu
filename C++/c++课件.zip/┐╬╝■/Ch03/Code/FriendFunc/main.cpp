#include <iostream>
#include "Point.h"

using namespace std;

int main(){
	Point a;
	Point b;

	a.setX(3.0);
	a.setY(5.0);
	b.setX(4.0);
	b.setY(6.0);
	double d=Distance(a,b);
	cout << "This Distance is : " << d << endl;

	return 0;
}