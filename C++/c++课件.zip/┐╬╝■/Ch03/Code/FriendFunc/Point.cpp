#include "Point.h"
#include <math.h>

void Point::setX(double x){
	X=x;
}

void Point::setY(double y){
	Y=y;
}

double Point::getX(){
	return X;
}

double Point::getY(){
	return Y;
}

double Distance(Point &a,Point &b){
	double dx=a.X-b.X;
	double dy=a.Y-b.Y;

	return sqrt(dx*dx+dy*dy);
}
