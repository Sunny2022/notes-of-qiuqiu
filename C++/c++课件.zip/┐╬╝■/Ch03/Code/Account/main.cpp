#include <iostream>
#include "Account.h"

using namespace std;

int main() {
	Account acc1, acc2, acc3, acc4, acc5, acc6;

	initialize(&acc1, "张三", "620523198210112368", 10.0);
	deposit(&acc1, 1000);

	withdraw(&acc1, 100);

	cout << "Name: " << acc1.sName << endl << "ID: " << acc1.sID << endl
	     << "Account: " << get_balance(acc1) << endl;

	return 0;
}
