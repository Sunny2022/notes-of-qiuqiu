#include "Account.h"
#include <string.h>

void initialize(Account *acc, char *sName,
                char *sID, float amount) {
	strcpy(acc->sName, sName);
	strcpy(acc->sID, sID);
	acc->fBalance = amount;
}
void deposit(Account *acc, float amount) { //往帐户中存钱
	acc->fBalance += amount;
}

bool withdraw(Account *acc, float amount) {  //取钱
	if (amount > acc->fBalance)
		return false;            //不允许透支

	acc->fBalance -= amount;
	return true;
}

float get_balance(Account acc) {  //查看帐户中的钱
	return acc.fBalance;
}
