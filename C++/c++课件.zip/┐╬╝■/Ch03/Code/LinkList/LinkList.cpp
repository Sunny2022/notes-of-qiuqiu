#include "LinkList.h"
#include <iostream>
using namespace std;

LinkList * Initilize() {
	LinkList *head;
	head = new LinkList;
	head->next = NULL;
	do {
		char ch;
		cin >> ch;
		if (ch == '@')
			break;
		LinkList *p1 = new LinkList;
		p1->ch = ch;
		p1->next = head->next;
		head->next = p1;
	}
	while (true);

	return head;
}

bool Insert(LinkList*head, int i, char ch) {
	int nCount = 1;
	LinkList *pWork, *pNew;

	pWork = head;
	while (nCount <= i) {
		pWork = pWork->next;
		if (pWork == NULL)
			return false;
		nCount++;
	}
	pNew = new LinkList;
	pNew->ch = ch;

	pNew->next = pWork->next;
	pWork->next = pNew;

	return true;
}

bool Delete(LinkList *head, int i) {
	LinkList *pWork = head->next, *pPre = head;
	int nCount = 1;

	while (pWork != NULL && nCount < i) {
		pPre = pWork;
		pWork = pWork->next;
		nCount++;
	}
	if (pWork != NULL) {
		pPre->next = pWork->next;
		delete pWork;
		return true;
	}
	return false;
}

bool Delete(LinkList * head, char ch) {
	LinkList *pWork = head->next, *pPre = head;
	int nCount = 1;

	while (pWork != NULL && pWork->ch != ch) {
		pPre = pWork;
		pWork = pWork->next;
	}
	if (pWork == NULL)
		return false;
	pPre->next = pWork->next;
	delete pWork;

	return true;
}

void Cleanup(LinkList *head) {
	LinkList *pWork;
	while (head != NULL) {
		pWork = head;
		head = head->next;
		delete pWork;
	}
}

void Display(LinkList *head) {
	LinkList *pWork = head->next;

	while (pWork != NULL) {
		cout << pWork->ch << ends;
		pWork = pWork->next;
	}
	cout << endl;
}
