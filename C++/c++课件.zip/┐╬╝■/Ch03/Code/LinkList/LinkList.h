#ifndef _LINKLIST_H_
#define _LINKLIST_H_

struct LinkList {
	char ch;
	struct LinkList *next;
};

LinkList * Initilize();
bool Insert(LinkList *head, int i, char ch);
bool Delete(LinkList *head, int i);
bool Delete(LinkList * head, char ch);
void Cleanup(LinkList *head);

void Display(LinkList *head);

#endif