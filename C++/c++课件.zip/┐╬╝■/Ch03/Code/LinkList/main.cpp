#include "LinkList.h"
#include <iostream>

using namespace std;

int main() {
	LinkList *head;

	head = Initilize();


	Display(head);
	Delete(head, 5);
	Display(head);
	Cleanup(head);

	return 0;
}
