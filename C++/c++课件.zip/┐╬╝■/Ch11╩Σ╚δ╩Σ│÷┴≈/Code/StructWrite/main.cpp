#include <iostream>
#include <fstream>
using namespace std;

struct student{
	char name[20];
	char id[20];
	float score;
};

int main(){
	ofstream output("stud",ios::out | ios::binary);
	student stu;

	while(true)	{
		cout << "Input name,id and score(score<0 to exit):";
		cin >> stu.name >> stu.id >> stu.score;
		if(stu.score<0)
			break;
		output.write((char*)&stu,sizeof(stu));
	}
	output.close();

	return 0;
}