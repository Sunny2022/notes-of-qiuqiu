#include <iostream>
#include <fstream>
using namespace std;

struct student{
	char name[20];
	char id[20];
	float score;
};

void display(char *);

int main(){
	ifstream input("stud",ios::in | ios::binary);
	student stud;
	ofstream ps("pass",ios::out | ios::binary);
	ofstream fl("failure",ios::out | ios::binary);

	while(true)	{
		input.read((char *)&stud,sizeof(stud));
		if(input.eof())
			break;
		if(stud.score>=60)
			ps.write((char * )&stud,sizeof(stud));
		else
			fl.write((char *)&stud,sizeof(stud));
	}
	input.close();
	ps.close();
	fl.close();
//*/
	cout << "All" << endl;
	display("stud");
	cout << endl << "Pass" << endl;
	display("pass");
	cout << endl << "Failure:" << endl;
	display("failure");
//*/
	return 0;
}

void display(char * filename)
{
	ifstream input;
	input.open(filename,ios::in | ios::binary);
	student stud;

	while(true){
		input.read((char *)&stud,sizeof(stud));
		if(input.eof())
			break;
		cout << stud.name << ends << stud.id << ends << stud.score << endl;
	}
	input.close();
}
