#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	char ch;
	ifstream input("main.cpp",ios::in);
	//ifstream input;
	//input.open("c:/boot.ini",ios::in);

	input.unsetf(ios::skipws);
	//input.setf(ios::skipws);�����ո���
	while(true){
		input >> ch;
		if(input.eof())
			break;
		cout << ch;
	}
	cout << endl;
	input.close();

	return 0;
}
