#include <iostream>
#include <iomanip>
using namespace std;

int main(){
	const int k = 618;
	cout << setw(10) << setfill('0') << setiosflags(ios::right) << k << endl;
	cout << setw(10) << setbase(8) << setfill('*') 
		 << resetiosflags(ios::right) << setiosflags(ios::left) << k << endl;

	double x = 22.07;
	int i;
	cout << "output in fixed:" << endl;
	cout << setiosflags(ios::fixed | ios::showpos);
	for(i=1;i<=5;i++){
		cout << setprecision(i) << x << ends;
	}
	cout << endl;
	cout << "output in scientific:" << endl;
	cout << resetiosflags(ios::fixed | ios::showpos) << setiosflags(ios::scientific);
	for(i=1;i<=5;i++){
		cout << setprecision(i) << x << ends;
	}
	cout << endl;

	return 0;
}