#include <iostream>
#include <fstream>
using namespace std;

int main(){
	char ch;
	ifstream input("main.cpp",ios::in);
	ofstream output("main_1.cpp",ios::out);

	input.unsetf(ios::skipws);
	while(true){
		input >> ch;
		if(input.eof())
			break;
		output << ch;
	}
	input.close();
	output.close();

	input.open("main.cpp",ios::in);
	output.open("main_2.cpp",ios::out);
	input.clear();output.clear();
	while(true){
		ch = input.get();
		if(input.eof())
			break;
		output.put(ch);
	}
	return 0;
}

