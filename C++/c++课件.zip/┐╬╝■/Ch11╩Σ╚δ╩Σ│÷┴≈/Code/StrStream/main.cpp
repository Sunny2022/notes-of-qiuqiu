#include <iostream>
#include <sstream>
#include <strstream>
#include <string>
#include <conio.h>
using namespace std;

int main(){
	string testStr("Input test 256 * 0.5");
	string s1,s2,s3;
	double x,y;
	istringstream input(testStr);

	input >> s1 >> s2 >> x >> s3 >> y;
	cout << s1 << ends << s2 << ends << x << ends << s3 << ends << y << endl;

	getch();
	istringstream input2("Input test 256 * 0.5");
	input2 >> s1 >> s2 >> x >> s3 >> y;
	cout << s1 << ends << s2 << ends << x << ends << s3 << ends << y << endl;

	getch();
	ostringstream output;
	double xx,yy;
	cout << "Input x:";  cin >> xx;
	cout << "Input y:";  cin >> yy;
	output << xx << " * " << yy << " = " << xx*yy << endl;
	cout << output.str() << endl;

	getch();
	char buf[80]={0};
	ostrstream output2(buf,sizeof(buf));
	cout << "Input x:"; cin >> xx;
	cout << "Input y:"; cin >> yy;
	output2 << xx << " * " << yy << " = " << xx*yy << endl;
	cout << buf << endl;

	return 0;
}
