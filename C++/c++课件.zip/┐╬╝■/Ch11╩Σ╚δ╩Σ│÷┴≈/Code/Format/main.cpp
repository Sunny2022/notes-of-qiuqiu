#include <iostream>
using namespace std;

int main(){
	cout << "123456789012345678901234567890" << endl;
	cout.setf(ios::left,ios::adjustfield);
	cout.width(10);
	cout << 55555 << endl;

	cout.setf(ios::right,ios::adjustfield); 
	cout.width(10);
	cout.fill('0');
	cout.setf(ios::showpos);
	cout << 55555 << endl;

	cout.setf(ios::internal,ios::adjustfield);
	cout.width(10);
	cout.fill('0');
	cout << -55555 << endl;

	cout.setf(ios::hex,ios::basefield);
	cout.setf(ios::showbase);
	cout << 255 << endl;
	cout.setf(ios::uppercase);
	cout << 255 << endl;

	cout.setf(ios::dec,ios::basefield);
	cout.setf(ios::showpoint);
	cout << 5.0 << endl;

	cout.setf(ios::scientific,ios::floatfield);
	cout.precision(5);
	cout << 5234.567890213334 << endl;

	int a;
	char b;
	float c;
	cin.unsetf(ios::skipws);
	cin >> a >> b >> c;
	cout << a << " " << b << " " << c << endl;
 
	return 0;
}
