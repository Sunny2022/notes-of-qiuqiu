#include <iostream>
#include "vector.h"
using namespace std;

int main(){
	int k,i;
	cin >> k;
	vector A(k);

	for(i=0;i<k;i++)
		A[i]=i+1;
	for(i=0;i<k;i++)
		cout << A[i] << " ";
	cout << endl;
	cout << "The size of A is: " << A() << endl;

	return 0;
}
