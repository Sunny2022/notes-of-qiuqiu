#ifndef _VECTOR_H_
#define _VECTOR_H_

class vector{
	int *v;
	int len;
public:
	vector(int size=1);
	vector(const vector & vct);
	~vector();
	int & operator[](int i);
	int operator()();
};

#endif