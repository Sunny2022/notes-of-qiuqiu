#include "vector.h"
#include <stdlib.h>
#include <iostream>
using namespace std;

vector::vector(int size/* =1 */){
	if (size<0){
		cout << "The size of " << size << " is null!" << endl;
		abort();
	}
	v=new int [size];
	len=size;
}

vector::vector(const vector & vct){
	len=vct.len;
	if(vct.v!=NULL){
		v=new int [len];
		for(int i=0;i<len;i++)
			v[i]=vct.v[i];
	}
}

vector::~vector(){
	if(v!=NULL){
		delete []v;
		len=0;
	}
}

int & vector::operator [](int i){
	return v[i];
}

int vector::operator()(){
	return len;
}
