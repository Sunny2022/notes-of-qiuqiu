#include "Integer.h"
#include <iostream>
using namespace std;

Integer::Integer(int ii/* =0 */){
	i=ii;
}
void Integer::show(){
	cout << i << endl;
}

Integer Integer::operator +(){
	return *this;
}

Integer Integer::operator -(){
	Integer temp(-i);
	return temp;
}

Integer Integer::operator ++(){
	i++;
	return *this;
}
Integer Integer::operator ++(int){
	Integer temp = *this;
	i++;
	return temp;
}

Byte::Byte(int bb/* =0 */){
	b=bb;
}

void Byte::show(){
	cout << b << endl;
}

Byte operator+(const Byte & bt){
	return bt;
}

Byte operator-(const Byte & bt){
	Byte temp(-bt.b);
	return temp;
}

Byte operator++(Byte & bt){
	bt.b++;
	return bt;
}

Byte operator++(Byte & bt,int){
	Byte temp=bt;
	bt.b++;
	return temp;
}