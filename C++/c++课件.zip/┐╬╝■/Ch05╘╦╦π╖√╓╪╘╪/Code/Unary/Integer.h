#ifndef _INTEGER_H_
#define _INTEGER_H_

class Integer{
	int i;
public:
	Integer(int ii=0);
	void show();
	Integer operator+();
	Integer operator-();
	Integer operator++();
	Integer operator++(int);
};

class Byte{
	int b;
public:
	Byte(int bb=0);
	void show();
	friend Byte operator+(const Byte & bt);
	friend Byte operator-(const Byte & bt);
	friend Byte operator++(Byte & bt);
	friend Byte operator++(Byte & bt,int);
};

#endif