#include "Integer.h"

int main(){
	Integer intObj(12);
	Byte btObj(11);

	+intObj;
	-btObj;
	btObj++;
	intObj++;

	return 0;
}
