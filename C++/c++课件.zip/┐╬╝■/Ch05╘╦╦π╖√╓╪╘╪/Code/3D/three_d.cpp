// three_d.cpp: implementation of the three_d class.
//
//////////////////////////////////////////////////////////////////////

#include "three_d.h"
#include <stdlib.h>
#include <iostream>
using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

three_d::three_d(int a,int b,int c){
	cout << "constructing \n";     

	x = a;
	y = b;
	z = c;
}

three_d::~three_d(){
	cout << "destructing \n";
}

void * three_d::operator new(size_t sz){
	cout << "in three_d new() \n";    //此处可以使用流对象cout，因为此时重载的new只对本类起作用。下同
	return malloc(sz);
}
void * three_d::operator new[](size_t sz){
	cout << "in three_d new[]()" << endl;
	return malloc(sz);
}
void three_d::operator delete(void * p){
	cout << "in three_d delete() \n";
	free(p);
}

void three_d::operator delete[](void *p){
	cout << "in threed delete[]()\n";
	free(p);
}

ostream & operator <<(ostream & stream,three_d & obj){
	stream << obj.x << " , ";
	stream << obj.y << " , ";
	stream << obj.z << " \n";

	return stream;
}