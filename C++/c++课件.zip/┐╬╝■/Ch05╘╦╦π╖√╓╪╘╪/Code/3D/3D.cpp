// 3D.cpp : Defines the entry point for the console application.
//

#include "three_d.h"
#include <stdio.h>
//#include <conio.h>
#include <iostream>
using namespace std;

int main(int argc, char* argv[]){
	three_d *p;

	p = new three_d(1,2,3);
	if(!p){
		cout << "alloction failure \n";
		return -1;
	}
	cout << * p << endl;
	delete p;
	cout << endl;

	cout << "int..." << endl;
	int *pint=new int(3);
	delete pint;

	getchar();
	cout << endl;
	p=new three_d[2];
	delete []p;
	cout << endl;

	return 0;
}
