// three_d.h: interface for the three_d class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_THREE_D_H__7907EC7F_A25C_4D7C_BBEF_F653ACB56B18__INCLUDED_)
#define AFX_THREE_D_H__7907EC7F_A25C_4D7C_BBEF_F653ACB56B18__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <iostream>

class three_d{
	int x,y,z;
public:
	three_d(){};
	three_d(int a,int b,int c);
	virtual ~three_d();

	void * operator new(size_t sz);
	void * operator new[](size_t sz);
	void operator delete(void * p);
	void operator delete[](void *p);
	friend std::ostream & operator <<(std::ostream & stream,three_d & obj);
};

#endif // !defined(AFX_THREE_D_H__7907EC7F_A25C_4D7C_BBEF_F653ACB56B18__INCLUDED_)
