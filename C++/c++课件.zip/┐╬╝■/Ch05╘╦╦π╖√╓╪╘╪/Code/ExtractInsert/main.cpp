#include <iostream>
#include "Complex.h"
using namespace std;

int main(){
	Complex c1,c2;
	cin >> c1 >> c2;
	cout << c1 <<endl << c2 << endl;f

	return 0;
}
