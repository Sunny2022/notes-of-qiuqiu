#include <iostream>
#include "Complex.h"
using namespace std;

Complex::Complex(){
	real=0; image=0;
}
Complex::Complex(float r,float i){
	real = r; image = i;
}

ostream& operator<<(ostream& os,const Complex &c){
	os << c.real << "+(" << c.image << ")i";

	return os;
}

istream& operator>>(istream& is,Complex &c){
	is >> c.real >> c.image;

	return is;
}