#ifndef _COMPLEX_H_
#define _COMPLEX_H_

class Complex
{
	float real,image;
public:
	Complex(float r=0,float i=0);
	Complex(const Complex & c);

	Complex Add(const Complex & right);
	Complex Subtract(const Complex & right);
	Complex Multiply(const Complex & right);
	Complex Divide(const Complex & right);
};

#endif