#include "Complex.h"

Complex::Complex(float r/* =0 */,float i/* =0 */){
	real=r;
	image=i;
}

Complex::Complex(const Complex & c){
	real=c.real;
	image=c.image;
}

Complex Complex::Add(const Complex & right){
	float r,i;

	r=real + right.real;
	i=image + right.image;

	Complex temp(r,i);
	return temp;
}

Complex Complex::Subtract(const Complex & right){
	float r,i;

	r = real - right.real;
	i = image - right.image;

	Complex temp(r,i);
	return temp;
}

Complex Complex::Multiply(const Complex & right){
	float r,i;

	r = real * right.real - image * right.image;
	i = real * right.image + image * right.real;

	Complex temp(r,i);
	return temp;
}

Complex Complex::Divide(const Complex & right){
	float r,i,mod;

	mod = right.real * right.real + right.image * right.image;
	r = (real * right.real + image * right.real) / mod;
	i = (image * right.real - real * right.image) /mod;

	Complex temp(r,i);
	return temp;
}