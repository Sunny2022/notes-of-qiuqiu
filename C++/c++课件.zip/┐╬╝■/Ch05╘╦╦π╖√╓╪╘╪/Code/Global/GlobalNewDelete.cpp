#include <stdio.h>
#include <stdlib.h>

void * operator new(size_t sz){
	printf("Operator new:%d bytes\n",sz);  //这里不能用流对象cout，因为用cout输出时，内部调用了new运算符，
                                           //所以会引起无法终止的递归。下面的new和delete中的情况同理
	void * m = malloc(sz);
	if(!m)
		 puts ("out of memeory");

	return m;
}

void * operator new[](size_t sz){
	printf("Operator new[]:%d bytes\n",sz);
	void *m=malloc(sz);
	if(!m)
		puts("out of memory");

	return m;
}

void operator delete(void * m){
	puts("operator delete");

	free(m);
}

int main(int argc, char* argv[]){
	puts("Creating & Destroying an int");
	int * p = new int(47);
	printf("%d\n", *p);

	delete p;

	p=new int[24];

	int i;

	for(i=0;i<24;i++)
		p[i]=i;
	for(i=0;i<24;i++)
		printf("%d ",p[i]);
	printf("\n");

	delete []p;

	return 0;
}
