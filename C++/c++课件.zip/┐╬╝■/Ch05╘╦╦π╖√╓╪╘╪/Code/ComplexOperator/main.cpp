#include "Complex.h"
#include <iostream>
using namespace std;

int main(){
	Complex left(1,2),right(3,4);

	Complex result = left + right;

	cin >> left;
	cout << left << endl;

	if(left)
		cout << "left is not 0" << endl;
	else
		cout << "left is 0" << endl;

    return 0;
}
