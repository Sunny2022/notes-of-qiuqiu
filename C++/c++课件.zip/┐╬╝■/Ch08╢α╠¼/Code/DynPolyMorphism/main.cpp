#include <iostream>
using namespace std;

class vehicle{
public:
	void drive(){
		cout << "drive a generic vehicle" << endl;
	}
};

class car:public vehicle{
public:
	void drive(){
		cout << "drive a car" << endl;
	}
};

void f(vehicle & v){
	v.drive();
}

void g(vehicle * pV){
	pV->drive();
}

int main(){
	vehicle vh;
	car c;

	f(vh);   //此函数调用哪一个类中的drive()?
	f(c);    //此函数调用哪一个类中的drive()?

	g(&vh);  //此函数调用哪一个类中的drive()?
	g(&c);   //此函数调用哪一个类中的drive()?

	vehicle *pVh;
	pVh=&vh;
	pVh->drive();
	pVh=&c;
	pVh->drive();

	return 0;
}