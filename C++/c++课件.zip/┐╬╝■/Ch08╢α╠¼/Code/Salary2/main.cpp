#include <iostream>
#include <string>
#include <iomanip>
#include "Employee.h"
#include "Manager.h"
#include "PieceWorker.h"
#include "HourlyWorker.h"
using namespace std;

void AddFront(Employee * &h, Employee *&t) {
	t->next = h;
	h = t;
}

void test3() {
	Employee * empHead = NULL, *ptr;
	
	ptr = new Manager(10135, "Cheng ShaoHua", 1200);
	AddFront(empHead, ptr);
	ptr = new HourlyWorker(30712, "Zhao XiaoMing", 5, 8*20);
	AddFront(empHead, ptr);
	ptr = new PieceWorker(20382, "Xiu LiWei", 0.5, 2850);
	AddFront(empHead, ptr);
	
	ptr = empHead;
	while (ptr) {
		ptr->print();
		ptr = ptr->next;
	}
	
	ptr = empHead;
	while (ptr) {
		cout << ptr->getName() << " " << ptr->earnings() << endl;
		ptr = ptr->next;
	}
}

int main() {
	test3();

	return 0;
}