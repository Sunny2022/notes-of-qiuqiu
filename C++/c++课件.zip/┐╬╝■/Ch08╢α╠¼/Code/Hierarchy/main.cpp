#include <iostream>
using namespace std;

class Root
{
public:
	virtual void vf()
	{
		cout << "Base::vf()" << endl;
	}
};

class FirstLevel:public Root
{
public:
	void vf()
	{
		cout << "FirstLevel::vf()" << endl;
	}
};

class SecondLevel:public FirstLevel
{
public:
	void vf()
	{
		cout << "SecondLevel::vf()" << endl;
	}
};

int main()
{
	Root * ptr;

	ptr = new Root;
	ptr->vf();
	delete ptr;

	ptr = new FirstLevel;
	ptr->vf();
	delete ptr;

	ptr = new SecondLevel;
	ptr->vf();
	delete ptr;

	return 0;
}