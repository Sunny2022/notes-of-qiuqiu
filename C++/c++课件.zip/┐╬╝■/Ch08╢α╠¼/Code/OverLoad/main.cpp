#include <iostream>
using namespace std;

class X
{
public:
	void Show(){ cout << "X::Show()" << endl; }
};

class Y:public X
{
public:
	void Show(int){ cout << "Y::Show(int)" << endl; }
	void Show(){ cout << "Y::Show()" << endl;}
};


int main()
{
	X xObj;
	Y yObj;

	xObj.Show();
	yObj.Show(10);
	yObj.Show();
	yObj.X::Show();

	return 0;
}