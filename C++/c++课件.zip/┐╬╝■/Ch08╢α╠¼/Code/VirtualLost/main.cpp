#include <iostream>
using namespace std;

class Base
{
public:
	virtual void f(int x)
	{
		cout << "Base::f(int)" << endl;
	}
};

class Derived:public Base
{
public:
	void f()
	{
		cout << "Derived::f()" << endl;
	}
};


int main()
{
	Base *ptr = new Derived;

	ptr->f(1);

	return 0;
}
