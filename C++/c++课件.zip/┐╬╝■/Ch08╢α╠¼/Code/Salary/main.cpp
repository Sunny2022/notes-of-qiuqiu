#include <iostream>
#include <string>
#include <iomanip>
#include "Employee.h"
#include "Manager.h"
#include "PieceWorker.h"
#include "HourlyWorker.h"
using namespace std;

void test1() {
	cout << setprecision(2);

	Manager m1(10135, "Cheng ShaoHua", 1200);
	Manager m2(10201, "Yan HaiFeng");
	m2.setMonthlySalary(5300);

	HourlyWorker hw1(30712, "Zhao XiaoMing", 5, 8*20);
	HourlyWorker hw2(30649, "Gao DongSheng");
	hw2.setWage(4.5);
	hw2.setHours(10*30);

	PieceWorker pw1(20382, "Xiu LiWei", 0.5, 2850);
	PieceWorker pw2(20496, "Huang DongLin");
	pw2.setWage(0.75);
	pw2.setQuantity(1850);

	Employee * basePtr;
	basePtr = &m1;
	basePtr->print();
	basePtr = &m2;
	basePtr->print();
	basePtr = &hw1;
	basePtr->print();
	basePtr = &hw2;
	basePtr->print();
	basePtr = &pw1;
	basePtr->print();
	basePtr = &pw2;
	basePtr->print();
}

void test2() {
	Employee * employ[6];
	employ[0] = new Manager(10135, "Cheng ShaoHua", 1200);
	employ[1] = new Manager(10201, "Yan HaiFeng", 5300);
	employ[2] = new HourlyWorker(30721, "Zhao XiaoMing", 5, 8*20);
	employ[3] = new HourlyWorker(30649, "Gao DongSheng", 4.5, 10*30);
	employ[4] = new PieceWorker(20382, "Liu LiWei", 0.5, 2850);
	employ[5] = new PieceWorker(20496, "Huang DongLin", 0.75, 1850);

	int i;

	cout << setprecision(2);
	for (i = 0;i < 5;i++)
		employ[i]->print();
	for (i = 0;i < 5;i++)
		cout << employ[i]->getName() << " " << employ[i]->earnings() << endl;
}

int main() {
	test1();

	return 0;
}
