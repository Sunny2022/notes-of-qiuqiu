#include <iostream>
using namespace std;

class graph
{
protected:
	double x,y;
public:
	void set_dim(double i,double j=0)
	{
		x=i; 
		y=j;
	}
	virtual double area();       //Ӧ�������ͼ�ε����?Ӧ�����ʵ�ָú���?
};

class triangle:public graph
{
public:
	double area()
	{
		return 0.5 * x * y;
	}
};

class square:public graph
{
public:
	double area()
	{
		return x * y;
	}
};

class circle:public graph
{
public:
	double area()
	{
		return 3.1415926 * x * x;
	}
};

int main()
{
	triangle t;
	square s;
	circle c;

	t.set_dim(10.0,5.0);
	cout << t.area() << endl;

	s.set_dim(10.0,5.0);
	cout << s.area() << endl;

	c.set_dim(9.0);
	cout << c.area() << endl;

	return 0;
}
