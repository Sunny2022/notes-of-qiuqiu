// GraphicDemo.h : main header file for the GRAPHICDEMO application
//

#if !defined(AFX_GRAPHICDEMO_H__8AACEBCB_8F5A_463A_9FFB_134C3A6DD52A__INCLUDED_)
#define AFX_GRAPHICDEMO_H__8AACEBCB_8F5A_463A_9FFB_134C3A6DD52A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoApp:
// See GraphicDemo.cpp for the implementation of this class
//

class CGraphicDemoApp : public CWinApp
{
public:
	CGraphicDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGraphicDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CGraphicDemoApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRAPHICDEMO_H__8AACEBCB_8F5A_463A_9FFB_134C3A6DD52A__INCLUDED_)
