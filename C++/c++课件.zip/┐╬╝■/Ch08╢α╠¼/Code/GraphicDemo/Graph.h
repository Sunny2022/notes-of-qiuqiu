// Graph.h: interface for the CGraph class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPH_H__AAAD1E4A_CEF8_479A_BD73_A4E10BDB6C0D__INCLUDED_)
#define AFX_GRAPH_H__AAAD1E4A_CEF8_479A_BD73_A4E10BDB6C0D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGraph  
{
	int x,y;
public:
	CGraph(int xx,int yy);
	virtual ~CGraph();
	int getX()const;
	int getY()const;

	void Draw(CDC &dc);
};

#endif // !defined(AFX_GRAPH_H__AAAD1E4A_CEF8_479A_BD73_A4E10BDB6C0D__INCLUDED_)
