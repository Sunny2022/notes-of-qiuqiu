// Rectangle.cpp: implementation of the CRectangle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GraphicDemo.h"
#include "Rectangle.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRectangle::CRectangle(int lft,int tp,int rgt,int btm):CGraph((rgt+lft)/2,(tp+btm)/2)
{
	left=lft;top=tp;
	right=rgt;bottom=btm;
}

CRectangle::~CRectangle()
{

}

void CRectangle::Draw(CDC &dc)
{
	dc.Rectangle(left,top,right,bottom);
}