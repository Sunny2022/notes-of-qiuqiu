// Graph.cpp: implementation of the CGraph class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GraphicDemo.h"
#include "Graph.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraph::CGraph(int xx,int yy)
{
	x=xx;y=yy;
}

CGraph::~CGraph()
{

}


void CGraph::Draw(CDC &dc)
{
	dc.TextOut(x,y,"This is a Graph Object");
}

int CGraph::getX()const
{
	return x;
}

int CGraph::getY()const
{
	return y;
}