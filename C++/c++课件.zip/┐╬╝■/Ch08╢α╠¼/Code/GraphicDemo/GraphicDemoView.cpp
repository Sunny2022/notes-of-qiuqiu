// GraphicDemoView.cpp : implementation of the CGraphicDemoView class
//

#include "stdafx.h"
#include "GraphicDemo.h"

#include "GraphicDemoDoc.h"
#include "GraphicDemoView.h"

#include "Graph.h"
#include "Circle.h"
#include "rectangle.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoView

IMPLEMENT_DYNCREATE(CGraphicDemoView, CView)

BEGIN_MESSAGE_MAP(CGraphicDemoView, CView)
	//{{AFX_MSG_MAP(CGraphicDemoView)
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoView construction/destruction

CGraphicDemoView::CGraphicDemoView()
{
	// TODO: add construction code here

}

CGraphicDemoView::~CGraphicDemoView()
{
}

BOOL CGraphicDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoView drawing

void CGraphicDemoView::OnDraw(CDC* pDC)
{
	CGraphicDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoView printing

BOOL CGraphicDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CGraphicDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CGraphicDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoView diagnostics

#ifdef _DEBUG
void CGraphicDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CGraphicDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGraphicDemoDoc* CGraphicDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGraphicDemoDoc)));
	return (CGraphicDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGraphicDemoView message handlers

void CGraphicDemoView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CClientDC dc(this);

	CGraph g(100,30),*pG=&g;
	CCircle cir(100,100,50);
	CRectangle rct(100,200,300,300);

	pG->Draw(dc);

	pG=&cir;
	pG->Draw(dc);

	pG=&rct;
	pG->Draw(dc);
	
	CView::OnLButtonDblClk(nFlags, point);
}
