// Circle.h: interface for the CCircle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CIRCLE_H__A2BD6329_1318_4B26_B48E_5A8E79698BF0__INCLUDED_)
#define AFX_CIRCLE_H__A2BD6329_1318_4B26_B48E_5A8E79698BF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Graph.h"

class CCircle : public CGraph  
{
	int r;
public:
	CCircle(int xx,int yy,int r);
	virtual ~CCircle();

	void Draw(CDC & dc);
};

#endif // !defined(AFX_CIRCLE_H__A2BD6329_1318_4B26_B48E_5A8E79698BF0__INCLUDED_)
