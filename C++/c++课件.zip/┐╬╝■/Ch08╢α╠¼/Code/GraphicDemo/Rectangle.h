// Rectangle.h: interface for the CRectangle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECTANGLE_H__824DFC4E_8155_4D90_BD27_052774C1772A__INCLUDED_)
#define AFX_RECTANGLE_H__824DFC4E_8155_4D90_BD27_052774C1772A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "graph.h"

class CRectangle:public CGraph  
{
	int left,top,right,bottom;
public:
	CRectangle(int lft,int tp,int rgt,int btm);
	virtual ~CRectangle();
	
	void Draw(CDC & dc);
};

#endif // !defined(AFX_RECTANGLE_H__824DFC4E_8155_4D90_BD27_052774C1772A__INCLUDED_)
