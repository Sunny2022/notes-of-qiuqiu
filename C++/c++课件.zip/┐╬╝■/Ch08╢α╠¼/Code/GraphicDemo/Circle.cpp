// Circle.cpp: implementation of the CCircle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GraphicDemo.h"
#include "Circle.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCircle::CCircle(int xx,int yy,int rr):CGraph(xx,yy)
{
	r=rr;
}

CCircle::~CCircle()
{

}

void CCircle::Draw(CDC & dc)
{
	dc.Ellipse(getX()-r,getY()-r,getX()+r,getY()+r);
}