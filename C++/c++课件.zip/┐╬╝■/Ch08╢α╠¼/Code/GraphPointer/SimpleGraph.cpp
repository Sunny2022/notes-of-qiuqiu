#include <iostream>
using namespace std;

class graph {
protected:
	double x, y;
public:
	void set_dim(double i, double j = 0) {
		x = i;
		y = j;
	}
	virtual double area() = 0;       //Ӧ�������ͼ�ε����?Ӧ�����ʵ�ָú���?
};

class triangle: public graph {
public:
	double area() {
		return 0.5 * x * y;
	}
};

class square: public graph {
public:
	double area() {
		return x * y;
	}
};

class circle: public graph {
public:
	double area() {
		return 3.1415926 * x * x;
	}
};

int main() {
	graph *p;
	triangle t;
	square s;
	circle c;
	
	p = &t;
	p->set_dim(10.0, 5.0);
	cout << p->area() << endl;
	
	p = &s;
	p->set_dim(10.0, 5.0);
	cout << p->area() << endl;
	
	p = &c;
	p->set_dim(9.0);
	cout << p->area() << endl;

	return 0;
}
