#ifndef _MANAGER_H_
#define _MANAGER_H_

#include "Employee.h"

class Manager: public Employee {
protected:
	double monthlySalary;
public:
	Manager(const long, const char *, double = 0.0);
	~Manager() {}
	void setMonthlySalary(double);
	virtual double earnings()const;
	virtual void print()const;
};

#endif