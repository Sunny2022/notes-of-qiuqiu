#include "Employee.h"
#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

Employee::Employee(const long k, const char *str) {
	number = k;
	name = new char[strlen(str)+1];
	strcpy(name, str);
}

Employee::~Employee() {
	delete []name;
}

const long Employee::getNumber()const {
	return number;
}

const char * Employee::getName()const {
	return name;
}

void Employee::print()const {
	cout << number << setw(16) << name;
}