#ifndef _HOURLY_WORKER_
#define _HOURLY_WORKER_

class HourlyWorker: public Employee {
public:
	HourlyWorker(const long, const char *, double = 0.0, int = 0);
	~HourlyWorker() {}
	void setWage(double);
	void setHours(int);
	virtual double earnings()const;
	virtual void print()const;
private:
	double wage;
	double hours;
};

#endif
