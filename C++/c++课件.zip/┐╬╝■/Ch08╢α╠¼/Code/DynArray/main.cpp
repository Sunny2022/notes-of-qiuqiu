#include <iostream>
#include <iomanip>
#include "Employee.h"
#include "HourlyWorker.h"
#include "Manager.h"
#include "PieceWorker.h"

using namespace std;
int main() {
	Employee* employ[6];
	
	employ[0] = new Manager(10135, "Cheng ShaoHua", 1200);
	employ[1] = new Manager(10201, "Yan HaiFen", 5300);
	employ[2] = new HourlyWorker(30712, "Zhao XiaoMing", 5, 8*20);
	employ[3] = new HourlyWorker(30649, "Gao DongSheng", 4.5, 10*30);
	employ[4] = new PieceWorker(20382, "Xiu LiWei", 0.5, 2850);
	employ[5] = new PieceWorker(20496, "Huang DongLin", 0.75, 1850);
	
	cout << setiosflags(ios::fixed | ios::showpoint) << setprecision(2);
	for (int i = 0; i < 6; i++)
		employ[i]->print();
	for (i = 0; i < 6; i++)
		cout << employ[i]->getName() << " " << employ[i]->earnings() << endl;
		
	for (i = 0; i < 6; i++)
		delete employ[i];

	return 0;
}