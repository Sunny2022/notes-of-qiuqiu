#ifndef _EMPLOYEE_H_
#define _EMPLOYEE_H_

class Employee {
protected:
	long number;
	char * name;
public:
	Employee(const long, const char *);
	virtual ~Employee();
	const char * getName()const;
	const long getNumber()const;
	virtual double earnings() const = 0;
	virtual void print() const;
};

#endif