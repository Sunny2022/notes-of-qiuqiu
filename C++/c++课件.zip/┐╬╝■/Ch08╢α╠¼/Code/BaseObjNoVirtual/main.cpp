#include <iostream>
using namespace std;


class Base{
public:
	virtual void f(){ cout << "Base::f()" << endl;}
};
class Derived:public Base{
public:
	void f(){ cout << "Derived1::f()" << endl;}
};

int main()
{
	Base b;
	Derived d;
	b.f();       //调用哪一个f()?
	b = d;
	b.f();       //调用哪一个f()?	

	return 0;
}