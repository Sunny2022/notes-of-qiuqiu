#ifndef _PIECE_WORKER_H_
#define _PIECE_WORKER_H_

class PieceWorker:public Employee
{
public:
	PieceWorker(const long,const char*,double=0.0,int=0);
	~PieceWorker(){}
	void setWage(double);
	void setQuantity(int);
	virtual double earnings()const;
	virtual void print()const;
private:
	double wagePerPiece;
	int quantity;
};

#endif