#include <iostream>
#include <string>
using namespace std;

class Base
{
public:
	~Base()
	{
		cout << "Base destructor is called" << endl;
	}
	virtual void f(){cout << "Base::f()" << endl; }
};

class Derived:public Base
{
	char *v;
	int len;
public:
	Derived(char *str)
	{
		len = strlen(str);
		v=NULL;
		if (len!=0)
			v = new char[len + 1];
	}
	~Derived()
	{
		cout << "Derived destructor is called" << endl;
		if (v)
			delete [] v;
	}
	void f(){cout << "Derived::f()" << endl; }
};

int main()
{
	Base * ptr;

	ptr = new Derived("����");
	ptr->f();
	delete ptr;

	return 0;
}