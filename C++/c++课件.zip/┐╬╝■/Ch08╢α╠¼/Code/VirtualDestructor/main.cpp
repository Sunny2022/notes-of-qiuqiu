#include <iostream>
#include <string>
using namespace std;

class Base
{
public:
	virtual void f(){ cout << "Base::f()" << endl;}
	virtual ~Base()
	{
		cout << "Base destructor is called" << endl;
	}
};

class Derived:public Base
{
	char *v;
	int len;
public:
	Derived(char *str)
	{
		len = strlen(str); 
		v = NULL;
		if (len!=0)
			v = new char [len + 1];
	}
	void f(){ cout << "Derived::f()" << endl;}
	virtual ~Derived()
	{
		cout << "Derived destructor is called" << endl;
		if (v)
			delete []v;
	}
};

int main()
{
	Base * ptr;

	ptr = new Derived("����");
	ptr->f();
	delete ptr;

	return 0;
}