#include <iostream>
using namespace std;

class Number {
protected:
	int val;
public:
	Number(int i) {
		val = i;
	}
	virtual void Show() = 0;
};

class Hex_type: public Number {
public:
	Hex_type(int i): Number(i) {}
	void Show() {
		cout << "Hexadecimal: " << hex << val << endl;
	}
};

class Dec_type: public Number {
public:
	Dec_type(int i): Number(i) {}
	void Show() {
		cout << "Decimal: " << dec << val << endl;
	}
};

class Oct_type: public Number {
public:
	Oct_type(int i): Number(i) {}
	void Show() {
		cout << "Octal: " << oct << val << endl;
	}
};

void fun(Number & n) {
	n.Show();
}

int main() {
	Dec_type n1(50);
	fun(n1);
	
	Hex_type n2(50);
	fun(n2);
	
	Oct_type n3(50);
	fun(n3);

	return 0;
}