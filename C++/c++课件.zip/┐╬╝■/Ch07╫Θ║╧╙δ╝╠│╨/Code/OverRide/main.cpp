#include <iostream>
using namespace std;

class Base{
public:
	void f(int x){
		cout << "Base::f()" << endl;
	}
};

class Derived:public Base{
public:
	void f(int x){
		cout << "Derived::f()" << endl;
	}
};

int main(){
	Derived dObj;
	dObj.f(10);

	return 0;
}