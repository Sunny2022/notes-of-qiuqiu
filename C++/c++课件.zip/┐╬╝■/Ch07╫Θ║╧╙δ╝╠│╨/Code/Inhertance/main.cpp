#include <iostream>
using namespace std;

class vehicle
{
public:
	void drive()
	{
		cout << "drive a generic vehicle" << endl;
	}
};

class car:public vehicle
{
public:
	void drive()
	{
		cout << "drive a car" << endl;
	}
};

void f(vehicle & v)
{
	v.drive();
}

int main()
{
	vehicle vh;
	car c;

	f(vh);
	f(c);

	return 0;
}
