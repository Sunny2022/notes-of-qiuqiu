#include <iostream>
using namespace std;

class CBase1 {
protected:
	int i;
public:
	void show_i()const {
		cout << i << endl;
	}
};

class CBase2 {
protected:
	int j;
public:
	void show_j()const {
		cout << j << endl;
	}
};

class CDerived: public CBase1, public CBase2 {
public:
	void set(int x, int y) {
		i = x;
		j = y;
	}
};

int main() {
	CDerived dObj;
	
	dObj.set(10, 100);
	dObj.show_i();
	dObj.show_j();
	
	return 0;
}