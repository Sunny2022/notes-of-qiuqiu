#ifndef _CIRCLE_H_
#define _CIRCLE_H_

#include "Point.h"
#include <iostream>

class Circle:public Point{
	friend std::ostream & operator << (std::ostream&,const Circle &);
public:
	Circle(double r=0.0,int x=0,int y=0);
	void setRadius(double);
	double getRadius() const;
	double area()const;
protected:
	double radius;
};

#endif