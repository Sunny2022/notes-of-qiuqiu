#ifndef _CYLINDER_H_
#define _CYLINDER_H_

#include <iostream>
#include "Circle.h"

class Cylinder:public Circle{
	friend std::ostream& operator << (std::ostream & ,const Cylinder &);
public:
	Cylinder(double h=0,double r=0,int x=0,int y=0);
	void setHeight(double);
	double getHeigt()const;
	double area()const;
	double volume()const;
protected:
	double height;
};

#endif


