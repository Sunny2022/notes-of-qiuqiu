#include "Cylinder.h"
#include <iostream>
#include <iomanip>
using namespace std;

Cylinder::Cylinder(double h,double r,int x,int y):Circle(r,x,y){
	setHeight(h);
}

void Cylinder::setHeight(double h){
	height = (h >= 0 ? h : 0);
}

double Cylinder::getHeigt()const{
	return height;
}

double Cylinder::area()const{
	return 2*Circle::area() + 2 * 3.1415926 * radius * height;
}

double Cylinder::volume()const{
	return Circle::area() * height;
}

ostream & operator << (ostream & output,const Cylinder & cy){
	output << "Center= " << '[' << cy.x << "," << cy.y << "]" << ";"
		   << "Radius= " << setprecision(2) << cy.radius
		   << ";Height= " << cy.height << endl;
	return output;
}
