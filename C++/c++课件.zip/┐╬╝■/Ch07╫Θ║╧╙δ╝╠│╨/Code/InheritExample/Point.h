#ifndef _POINT_H_
#define _POINT_H_
#include <iostream>

class Point{
	friend std::ostream & operator<<(std::ostream &,const Point &);
public:
	Point(int =0,int =0);
	void setPoint(int,int);
	int getX() const {return x;}
	int getY() const {return y;}
protected:
	int x,y;
};

#endif