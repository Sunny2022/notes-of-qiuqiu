#include <iostream>
#include "Point.h"
#include "Circle.h"
#include "Cylinder.h"
using namespace std;

int main()
{
	Point p(72,115);
	cout << "The initial location of p is " << p << endl;
	p.setPoint(10,10);
	cout << "\nThe new location of p is " << p << endl;

	Circle c(2.5,37,43);
	cout << "\nThe initial location and radius of c are " << endl << c
		 << "\nArea = " << c.area() << endl;
	c.setRadius(4.25);
	c.setPoint(2,2);
	cout << "\nThe new location and radius of c are" << endl << c
		 << "\nArea = " << c.area() << endl;

	Cylinder cyl(5.7,2.5,12,23);
	cout << "\nThe initial location,radius and height of cyl are" << endl << cyl
		 << "Area = " << cyl.area() << endl << "Volume = " << cyl.volume() << endl;
	cyl.setHeight(10);
	cyl.setRadius(4.25);
	cyl.setPoint(2,2);
	cout << "\nThe new location,radius and height of cyl are" << endl << cyl
		 << "Area = " << cyl.area() << "\nVolume = " << cyl.volume() << endl;

  return 0;
}
