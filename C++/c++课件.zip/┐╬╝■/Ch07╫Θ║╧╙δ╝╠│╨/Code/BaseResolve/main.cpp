#include <iostream>
using namespace std;

class B{
public:
	B(){
		cout << "Constructor called:B" << endl;
	}
	~B(){
		cout << "Destuctor called:B" << endl;
	}
	void f(){ }
};

class B1:public B{
public:
	B1(){
		cout << "Constructor called:B1" << endl;
	}
	~B1(){
		cout << "Destructor called:B1" << endl;
	}
	void f1(){ }
};

class B2:public B{
public:
	B2(){
		cout << "Constructor called:B2" <<endl;
	}
	~B2(){
		cout << "Destructor called:B2" << endl;
	}
	void f2(){ }
};

class D:public B1,public B2{
public:
	D(){
		cout << "Constructor called:D" << endl;
	}
	~D(){
		cout << "Destructor called:D" << endl;
	}
	void fd(){ }
};

int main(){
	D dd;

	dd.fd();
	dd.f1();
	dd.f2();
	dd.f();        //����f()�Ǵ���һ���̳�·�������ģ�
	dd.B1::f();
	dd.B2::f();

	return 0;
}
