#include <iostream>
using namespace std;

class CBase1{
public:
	void f(int x){
		cout << "In CBase1::f(int)" << endl;
	}
};

class CBase2{
public:
	void f(int x){
		cout << "In CBase2::f(int)" << endl;
	}
};

class CDerived:public CBase1,public CBase2{
public:
	void disp(){
		f(10);                    //调用的是从哪个基类继承下来的f() ?
	}
};

int main(){
	CDerived dObj;

	dObj.disp();

	dObj.f(1);                    //调用的是从哪个基类继承下来的f() ?

	return 0;
}
