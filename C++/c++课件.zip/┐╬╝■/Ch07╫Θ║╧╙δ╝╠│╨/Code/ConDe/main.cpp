#include <iostream>
using namespace std;

class Point{
	int x,y;
public:
	Point(int xx,int yy){
		x=xx; y=yy;
		cout<<"Point constructor ..." <<endl;
	}
	Point(Point & sp)	{
		x=sp.x; y=sp.y;
		cout<<"Point copy constructor ..."<<endl;
	}
	~Point(){cout<<"Destroying Point ..."<<endl;}
};

class Graph{
public:
	Graph()	{
		cout<<"Graph constructor ..."<<endl;
	}
	Graph(Graph &)	{
		cout<<"Graph copy constructor ..."<<endl;
	}
	~Graph()	{
		cout<<"Destroying Graph ..."<<endl;
	}
};
class Circle:public Graph{ 
	Point center;
	int r;
public:
	Circle(int xx,int yy,int radius):center(xx,yy){
		r=radius;
		cout << "Circle constructor1 ..." << endl;
	}
	Circle(Point &c,int radius):center(c){
		r=radius;
		cout<<"Circle constructor ..."<<endl;
	}
	Circle(Circle & c):center(c.center){
		r=c.r;
		cout<<"Circle copy constructor ..."<<endl;
	}
	~Circle(){
		cout<<"Destroying Circle ..."<<endl;
	}
};
int main(){ 
	Point pt(10,100);   cout << endl;
	Circle cir(pt,10); cout << endl;
	Circle cirBak=cir; cout << endl;

	return 0;
}
