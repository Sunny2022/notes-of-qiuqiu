#ifndef _VEHICLE_H_
#define _VEHICLE_H_

class vehicle
{
	int wheels;
	float weight;
	float loading;
public:
	vehicle(int wheels,float weight,float loading);
	int get_wheels();
	float get_weight();
	float get_loading();	
};

class Car:public vehicle
{
	int passenger_load;
public:
	Car(int in_wheels,float in_weight,float in_loading,int peoples=4);
	int passengers();	
};

#endif