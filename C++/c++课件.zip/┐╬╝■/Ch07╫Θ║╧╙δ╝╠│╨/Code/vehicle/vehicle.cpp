#include "vehicle.h"

vehicle::vehicle(int wheels,float weight,float loading)
{
	this->wheels = wheels;
	this->weight = weight;
	this->loading = loading;
}

int vehicle::get_wheels()
{
	return wheels;
}

float vehicle::get_weight()
{
	return weight;
}

float vehicle::get_loading()
{
	return loading;
}

Car::Car(int in_wheels,float in_weight,float in_loading,int peoples/* =4 */)
        :vehicle(in_wheels,in_weight,in_loading)
{
	passenger_load = peoples;
}

int Car::passengers()
{
	return passenger_load;
}