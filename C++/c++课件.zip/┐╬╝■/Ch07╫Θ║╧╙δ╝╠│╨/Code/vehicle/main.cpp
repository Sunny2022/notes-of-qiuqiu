#include <iostream>
#include "vehicle.h"
using namespace std;

int main()
{
	Car car(4,1000,1000,4);
	cout << car.passengers() 
		 << endl;
	cout << car.get_wheels() << ends
	     << car.get_weight() << ends
		 << car.get_loading() << endl;

	return 0;
}