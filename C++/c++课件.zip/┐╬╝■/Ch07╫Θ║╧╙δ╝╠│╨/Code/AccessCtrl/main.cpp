class A{
	int x;
	void f();
protected:
	int y;
	void g();
public:
	int z;
	void h();
};

class B:public A{
public:
	void func(){
		x=0;
		f();
		
		y=10;
		g();
		
		z=10;
		h();
	}
};

int main()
{
	return 0;
}