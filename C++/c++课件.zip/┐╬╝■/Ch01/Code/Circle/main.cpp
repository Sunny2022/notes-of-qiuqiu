#include <iostream>
using namespace std;

int main()
{
	float fR,fGirth,fArea;
	const float pi=3.1415926f;

	cout << "Enter radius:" << endl;
	cin >> fR;
	fGirth = 2*pi*fR*fR;
	fArea = pi*fR*fR;

	cout << "Radius= " << fR << endl;
	cout << "Girth= " << fGirth << endl;
	cout << "Area= " << fArea << endl;

	return 0;
}