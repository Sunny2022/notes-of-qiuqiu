#include <iostream>
using namespace std;
const float pi=3.1415926f;

class Circle{
	float radius;
 public:
   void Set_Radius(float r){radius=r;}
   float Get_Radius(){return radius;}
   float Girth(){return 2*pi*radius;}
   float Area(){return pi*radius*radius;}
};

int main(){
  Circle A,B;
   A.Set_Radius(6.23f);
   cout << "A.Radius= " << A.Get_Radius() << endl;
   cout << "A.Girth= " << A.Girth() << endl;
   cout << "A.Area= " << A.Area() << endl;

   B.Set_Radius(10.5f);
   cout << "B.Radius= " << B.Get_Radius() << endl;
   cout << "B.Girth= " << B.Girth() << endl;
   cout << "B.Area= " << B.Area() << endl;

   return 0;
}
