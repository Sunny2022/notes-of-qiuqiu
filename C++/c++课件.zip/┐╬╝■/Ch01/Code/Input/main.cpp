#include <iostream>
using namespace std;

int main()
{
	int nA;
	float fB;
	char cC;
	char pcD[20];

	cout << "Enter an integer, a float, a char & a string:";
	cin >> nA >> fB	>> cC >> pcD;

	cout << nA << " " << fB << " " << cC << " " << pcD << endl;

	return 0;
}
