#include <iostream>
using namespace std;

int main()
{
	cout << "Hello World!" << endl
	     << "This is our first C++ program."
	     << endl;

  return 0;
}
