
extern int nConflict;
extern int nNoConflict;
void funcConflict();
void funcNoConflict();

int main()
{
	nConflict=1;
	nNoConflict=2;
	funcConflict();
	funcNoConflict();

	return 0;
}
