int nConflict;
static int nNoConflict;

void funcConflict(){ }
static void funcNoConflict(){ }
