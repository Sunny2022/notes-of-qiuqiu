#include "classX.h"
using namespace MyLib;

int main()
{
	classX xObj(1);

	xObj.showX();

	return 0;
}