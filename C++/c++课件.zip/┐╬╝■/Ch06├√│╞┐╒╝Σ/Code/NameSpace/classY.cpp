#include "classY.h"
#include <iostream>
using namespace std;

//////////////////////////////////
MyLib::classY::classY(int yy)
{
	y=yy;
}

void MyLib::classY::showY()
{
	cout << y << endl;
}
/////////////////////////////////

/*/
//同样，上述这一段程序也可以这样实现
using namespace MyLib;

classY::classY(int yy)
{
	y=yy;
}

void classY::showY()
{
	cout << y << endl;
}
//*/