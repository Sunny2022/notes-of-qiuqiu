#ifndef _CLASS_Y_H_
#define _CLASS_Y_H_


namespace MyLib
{
	class classY
	{
		int y;
	public:
		classY(int yy);
		void showY();
	};
}
#endif