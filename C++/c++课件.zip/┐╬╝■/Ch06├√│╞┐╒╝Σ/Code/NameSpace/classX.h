#ifndef _CLASSX_H_
#define _CLASSX_H_

namespace MyLib
{
	class classX
	{
		int x;
	public:
		classX(int xx);
		void showX();
	};
}

#endif