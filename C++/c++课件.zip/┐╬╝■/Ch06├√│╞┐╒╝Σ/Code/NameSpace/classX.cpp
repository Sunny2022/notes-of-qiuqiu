#include "classX.h"
#include <iostream>
using namespace std;

//
/////////////////////////////////
MyLib::classX::classX(int xx)
{
	x=xx;
}

void MyLib::classX::showX()
{
	cout << x << endl;
}
/////////////////////////////////
//*/

/*/
//上述这一段程序也可以这样实现
using namespace MyLib;

classX::classX(int xx)
{
	x=xx;
}

void classX::showX()
{
	cout << x << endl;
}

//*/