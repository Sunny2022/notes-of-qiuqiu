#ifndef _USINGNAMESPACE_H_
#define _USINGNAMESPACE_H_

#include <iostream>

namespace DemoNameSpace
{
	void f()
	{
		std::cout << "This is in DemoNameSpace::f()" << std::endl;
	}
	void g()
	{
		std::cout << "This is in DemoNameSpace::g()" << std::endl;
	}
}

#endif