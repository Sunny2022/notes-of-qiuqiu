#include "namespace.h"
int main()
{
	using DemoNameSpace::f;
	f();                    //正确
//	g();                    //错
	DemoNameSpace::g();     //正确

	return 0;
}
