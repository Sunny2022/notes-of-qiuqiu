int nTestVar;

void funcTest(){ }
