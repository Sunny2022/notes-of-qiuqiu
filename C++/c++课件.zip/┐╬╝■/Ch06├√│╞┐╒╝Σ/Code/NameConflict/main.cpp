#include <iostream>
using namespace std;

extern int nTestVar;
void funcTest();
int main()
{
	nTestVar = 0;
	funcTest();

	return 0;
}
