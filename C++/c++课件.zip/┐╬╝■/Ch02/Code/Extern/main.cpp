#include <iostream>
using namespace std;

extern int nTestVar;
int main()
{
	nTestVar=100;
	cout << nTestVar << endl;

	return 0;
}
