#include <iostream>
#include <string>
using namespace std;

int main()
{
	string names[]={"Li Hua","He XiaoMing","Zhang Li","Sun Fei","Chen Bao"};
	string s;
	int i,j,k,nmb;

	nmb=sizeof(names)/sizeof(names[0]);
	for(i=0;i<nmb-1;i++)
	{
		k=i;
		for (j=i+1;j<nmb;j++)
			if(names[i]>names[j])
				k=j;
		if (k!=i)
		{
			s=names[k];
			names[k]=names[i];
			names[i]=s;
		}
	}
	for(i=0;i<nmb;i++)
		cout << "name[" << i << "]=" << names[i] << endl;

	return 0;
}