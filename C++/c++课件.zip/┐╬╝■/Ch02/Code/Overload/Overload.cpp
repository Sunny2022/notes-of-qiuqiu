#include <iostream.h>

int max(int x, int y) {
	cout << "int...  ";
	return x > y ? x : y;
}

float max(float x, float y) {
	cout << "float....  ";
	return x > y ? x : y;
}

long max(long x, long y) {
	cout << "long...  ";
	return x > y ? x : y;
}


int main(int argc, char* argv[]) {
	int nA = 10, nB = 15;
	float fA = 1.0, fB = 2.5;
	long lA = 1, lB = 10;
	
	cout << max(nA, nB) << endl;
	cout << max(fA, fB) << endl;
	cout << max(lA, lB) << endl;
	
	return 0;
}
