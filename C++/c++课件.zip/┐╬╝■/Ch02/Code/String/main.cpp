#include <iostream>
#include <string>
using namespace std;

void PrintAttribute(const string &str) {
	cout << "size: " << str.size() << endl;
	cout << "length: " << str.length() << endl;
}

int main() {
	string s1, s2;
	
	PrintAttribute(s1);
	s1 = "My string object";
	PrintAttribute(s1);
	s2 = "Another String Object";
	PrintAttribute(s2);
	
	return 0;
}