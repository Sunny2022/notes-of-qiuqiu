#include <iostream>
using namespace std;

int factor(int n)
{
	static int result=1;

	result*=n;

	return result;
}

int main()
{
	int n,result=0;;

	cin >> n;

	if (n<10)
	{
		int y=1000;
		for(int i=1;i<=n;i++)
		{
			int result=factor(i);
			cout << result << endl;
		}
	}
	cout << endl << result << endl;
//	cout << y << endl;

  return 0;
}
