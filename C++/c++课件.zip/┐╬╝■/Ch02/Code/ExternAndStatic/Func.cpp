#include <stdafx.h>
#include <iostream.h>

extern int fextern()
{
	cout << "This is extern fextern() in func.cpp " << endl;

	return 0;
}

static int fstatic()
{
	cout << "This is static fstatic() in func.cpp" << endl;

	return 0;
}