// ExternAndStatic.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

extern int fextern();
extern int fstatic();

int main(int argc, char* argv[])
{
	fextern();
	fstatic();
	
	return 0;
}
