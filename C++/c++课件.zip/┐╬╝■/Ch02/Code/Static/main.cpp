#include <iostream>
using namespace std;

int factor(int n)
{
	static int result=1;

	result*=n;
	return result;
}

int main()
{
	for(int i=1;i<=8;i++)
		cout << factor(i) << " ";
	cout << endl;

	return 0;
}
