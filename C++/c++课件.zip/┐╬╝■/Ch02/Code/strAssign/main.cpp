#include <iostream>
#include <string>
using namespace std;

int main()
{
	string s1="cat ",s2,s3;

	s2=s1; 
	s3.assign("jump ");
	cout << s2 << s3 << endl;

	s1+=s3;
	cout << s1 << endl;
	s1.append("and yell");
	cout << s1 << endl;
	s1[0]='h';
	cout << s1 << endl;

	return 0;
}