#include <iostream>
using namespace std;

void swap(int,int);
void swap(int *,int *);

int main()
{
	int nA=3,nB=5;
	int *pA=&nA,*pB=&nB;

	swap(nA,nB);
	cout << "After swap(int,int): nA=" << nA << ends << "nB=" << nB << endl;

	swap(pA,pB);
	cout << "After swap(int *,int*): nA=" << nA << ends << "nB=" << nB << endl;

  return 0;
}

void swap(int x,int y)
{
	int t;

	t=x;
	x=y;
	y=t;
}

void swap(int *px,int *py)
{
	int t;

	t=*px;
	*px=*py;
	*py=t;
}
