#include <iostream>
using namespace std;

void swap(int &, int &);

int main() {
	int nSomeVar = 10, nAnother = 100;
	int &ref = nSomeVar;

	ref++;
	cout << nSomeVar << endl;

	ref = nAnother;
	ref++;
	cout << nSomeVar << ends << nAnother << endl;

//	swap(nSomeVar,nAnother);
//	cout << "After swap(int &,int &): nSomevar=" << nSomeVar << " nAother=" << nAnother << endl;

  return 0;
}

void swap(int &x, int &y) {
	int t;

	t = x;	x = y;	y = t;
}
