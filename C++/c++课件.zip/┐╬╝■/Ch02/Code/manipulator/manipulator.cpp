#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	cout << 'A' << ends << 'B' << endl;
	cout << hex << 255 << ends << 32 << endl;
	cout << dec << setw(5) << setfill('0') << 32 << endl;
	cout << setw(5) << setprecision(4) << 7.5612 << endl;
	
	return 0;
}