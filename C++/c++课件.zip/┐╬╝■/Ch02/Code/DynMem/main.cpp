#include <iostream>
using namespace std;

int main()
{
	int *pInt;

	pInt=new int;

	*pInt=100;
	cout << * pInt << endl;
	delete pInt;

	pInt=new int (10);
	cout << *pInt << endl;
	delete pInt;

	int n,i;
	cin >> n;
	pInt=new int[n];
	for(i=0;i<n;i++)
		pInt[i]=i+1;
	for(i=0;i<n;i++)
		cout << pInt[i] << ends;
	cout << endl;
	delete []pInt;

	return 0;
}
