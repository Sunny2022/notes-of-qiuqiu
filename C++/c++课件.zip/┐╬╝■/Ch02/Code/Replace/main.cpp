#include <iostream>
#include <string>
using namespace std;

int main()
{
	string alphabet="A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
	int x=alphabet.find("A");
	while(x>=0)
	{
		alphabet.replace(x,1,";");
		x=alphabet.find(",",x+1);
	}
	cout << alphabet << endl;

	return 0;
}